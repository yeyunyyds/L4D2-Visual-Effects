#include "menu_font.hpp"
#include <stdexcept>
#include <iostream>
int main(){ImFontAtlas atlas;ImVector<ImWchar> ranges;dango::hud::menuFontRanges(atlas,ranges);
 const wchar_t* required=L"邦友的酒自定义喷漆同局自动匹配握手绑定数量限制预测锁敌瞄准毫秒停滞诊断样式预览琥珀战术冰蓝刻度横竖厚度模拟高级实体透视缩放前摇粗细精调倍率选中参数减少增加百分比参数设置窗口实体形变构建卸载兼容宽深倍率继承石头轨迹落点绿色橙蓝圆不透明度候选附属射线本机手持识别超时角色资料扇区提醒红底描边填充";
 for(auto c=required;*c;++c){bool found=false;for(int i=0;i+1<ranges.Size&&ranges[i];i+=2)if(*c>=ranges[i]&&*c<=ranges[i+1])found=true;if(!found)throw std::runtime_error("Required menu glyph omitted");}
 std::cout<<"PASS: menu atlas includes effect title and automatic spray discovery glyphs\n";
}
