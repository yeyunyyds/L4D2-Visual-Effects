#include "rock_melee.hpp"
#include <cassert>
#include <iostream>
using namespace visual::rocks;
Track moving(uint32_t handle,Vec3 p,Vec3 v){Track t;t.record.handle=handle;t.state=State::FlyingInferred;t.gravityValid=true;t.gravity=0;Sample s;s.position=p;s.velocity=v;s.velocityValid=true;s.wallMs=1000;t.history.push_back(s);return t;}
int main(){
 assert(meleeSegmentBox({0,0,0},{1,0,0},75,{90,0,0},16).intersects);assert(!meleeSegmentBox({0,0,0},{1,0,0},75,{92,0,0},16).intersects);
 assert(!meleeSegmentBox({0,0,0},{1,0,0},75,{-30,0,0},16).intersects);assert(meleeSegmentBox({0,0,0},{1,0,0},75,{0,0,0},16).intersects);
 assert(!meleeSegmentBox({0,0,0},{1,0,0},75,{50,17,0},16).intersects);assert(meleeSegmentBox({0,0,0},{1,0,0},75,{50,16,0},16).intersects);
 assert(!meleeSegmentBox({0,0,0},{},75,{50,0,0},16).intersects);assert(!meleeSegmentBox({0,0,0},{1,0,0},75,{50,0,0},-1).intersects);
 MeleeSettings s;assert(!s.enabled&&s.range==75&&s.windupMs==100);s.enabled=true;dango::CameraPose pose;pose.eye={0,0,0};pose.forward={1,0,0};
 MeleeTracker tracker;std::map<uint32_t,Track> tracks{{0x2007,moving(0x2007,{100,0,0},{-200,0,0})}};std::map<uint32_t,Landing> landings;
 auto frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(frame.results.at(0x2007).canSkeet&&!frame.results.at(0x2007).inRangeNow);assert(frame.entries==1&&frame.transitions.size()==1);assert(frame.results.at(0x2007).horizonMs==100);
 frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(frame.entries==1&&frame.transitions.empty());
 tracks.at(0x2007).history.back().position={140,0,0};frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(!frame.results.at(0x2007).canSkeet&&frame.exits==1);
 tracks.at(0x2007).history.back().position={100,0,0};s.offsetMs=-100;frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(frame.results.at(0x2007).horizonMs==0&&!frame.results.at(0x2007).canSkeet);
 s.offsetMs=0;s.includeArrivalAge=true;frame=tracker.evaluate(1,1020,tracks,&pose,s,16,landings);assert(frame.results.at(0x2007).horizonMs==120&&frame.results.at(0x2007).canSkeet);
 frame=tracker.evaluate(1,1300,tracks,&pose,s,16,landings);assert(!frame.results.at(0x2007).valid&&!frame.results.at(0x2007).canSkeet);
 tracks.at(0x2007).gravityValid=false;frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(!frame.results.at(0x2007).valid);tracks.at(0x2007).gravityValid=true;
 Landing hit;hit.state=LandingState::Impact;hit.sampleMs=hit.computedMs=1000;hit.seconds=.05f;landings[0x2007]=hit;frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(frame.results.at(0x2007).worldImpactKnown&&!frame.results.at(0x2007).canSkeet);landings.clear();
 tracks.emplace(0x3008,moving(0x3008,{60,0,0},{}));frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);assert(frame.results.size()==2&&frame.results.at(0x3008).canSkeet);tracks.erase(0x3008);frame=tracker.evaluate(1,1000,tracks,&pose,s,16,landings);bool departed=false;for(const auto& t:frame.transitions)if(t.handle==0x3008&&!t.entered)departed=true;assert(departed);
 frame=tracker.evaluate(2,1000,{},&pose,s,16,landings);assert(frame.results.empty()&&frame.entries==0&&frame.exits==0);s.enabled=false;frame=tracker.evaluate(2,1000,tracks,&pose,s,16,landings);assert(!frame.enabled&&frame.results.empty());
 nlohmann::json j={{"other",42}};s.enabled=true;s.range=95;s.offsetMs=-30;writeMeleeSettings(j,s);assert(!j["tankRockMelee"].contains("enabled"));auto loaded=readMeleeSettings(j);assert(!loaded.enabled&&loaded.range==95&&loaded.offsetMs==-30&&j["other"]==42);
 loaded=readMeleeSettings({{"tankRockMelee",{{"enabled",true},{"range",999},{"windupMs",-5},{"leadMs","bad"},{"offsetMs",-999}}}});assert(!loaded.enabled&&loaded.range==200&&loaded.windupMs==0&&loaded.leadMs==0&&loaded.offsetMs==-250);
 std::cout<<"PASS: finite aim ray, assumed box, range boundaries, manual timing, transitions, stale/invalid states, world impact, multi-identity/map reset and opt-in config\n";
}
