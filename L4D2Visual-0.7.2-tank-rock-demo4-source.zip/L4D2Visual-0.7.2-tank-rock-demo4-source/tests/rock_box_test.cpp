#include "rock_landing.hpp"
#include <cassert>
#include <iostream>
using namespace visual::rocks;
int main(){
 auto ray=dango::trace::boxRay({1,2,3},{10,2,3},{16,16,16});assert(!ray.isRay&&ray.isSwept&&ray.extents.x==16&&ray.start.x==1&&ray.offset.x==0&&ray.transform==0);
 auto point=dango::trace::boxRay({1,2,3},{10,2,3},{});assert(point.isRay&&point.extents.x==0);
 auto floor=[](float half){return [half](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;if(b.z<=half){r.fraction=(a.z-half)/(a.z-b.z);r.end=a+(b-a)*r.fraction;r.plane.normal={0,0,1};}return true;};};
 Sample sample;sample.position={0,0,100};sample.velocity={100,0,0};sample.velocityValid=true;unsigned budget=64;
 auto center=predictLanding(sample,320,100,budget,floor(0));budget=64;auto box=predictLanding(sample,320,100,budget,floor(16),16);
 assert(center.valid()&&box.valid()&&box.seconds<center.seconds);assert(std::abs(box.seconds-std::sqrt(168.f/320))<.002f);assert(std::abs(box.position.z)<.001f&&std::abs(box.centerPosition.z-16)<.001f);assert(box.assumedHalfSize==16);
 auto wall=[](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;if(b.x>=84){r.fraction=(84-a.x)/(b.x-a.x);r.end=a+(b-a)*r.fraction;r.plane.normal={-1,0,0};r.plane.distance=-100;}return true;};
 budget=64;box=predictLanding(sample,0,100,budget,wall,16);assert(box.valid());assert(std::abs(box.seconds-.84f)<.001f);assert(std::abs(box.centerPosition.x-84)<.001f&&std::abs(box.position.x-100)<.001f);
 dango::trace::Result result;wall({80,0,0},{85,0,0},result);assert(!dango::trace::valid(result,{80,0,0},{85,0,0}));assert(dango::trace::validSweep(result,{80,0,0},{85,0,0},{16,16,16}));
 sample.position={100,100,0};sample.velocity={-100,-100,0};auto slope=[](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;if(b.x<=16){r.fraction=(a.x-16)/(a.x-b.x);r.end=a+(b-a)*r.fraction;r.plane.normal=dango::normalize({1,1,0});}return true;};
 budget=64;box=predictLanding(sample,0,100,budget,slope,16);assert(box.valid());assert(dango::length(box.position)<.001f);assert(std::abs(box.seconds-.84f)<.001f);
 budget=64;auto bad=predictLanding(sample,0,100,budget,slope,2);assert(bad.state==LandingState::Invalid&&bad.rays==0);budget=64;bad=predictLanding(sample,0,100,budget,slope,std::numeric_limits<float>::quiet_NaN());assert(bad.state==LandingState::Invalid);
 assert(!dango::trace::validExtents({-1,1,1})&&!dango::trace::validExtents({65,1,1}));assert(nextAssumedHalfSize(12)==16&&nextAssumedHalfSize(64)==4);
 Tracker tracker;Options o;assert(!o.assumedHull&&o.hullHalfSize==16);o.hullHalfSize=100;tracker.configure(o);assert(tracker.options().hullHalfSize==64);o.hullHalfSize=-1;tracker.configure(o);assert(tracker.options().hullHalfSize==4);
 std::cout<<"PASS: assumed box ABI, earlier floor/wall contacts, center/contact distinction, oblique plane support, invalid extents and ray comparison\n";
}
