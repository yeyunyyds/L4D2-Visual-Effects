#pragma once
#include "rock_landing.hpp"
#include "dango/json.hpp"
namespace visual::rocks {
struct MeleeSettings {bool enabled=false,includeArrivalAge=false,drawRay=true;float range=75,leadMs=0,windupMs=100,offsetMs=0;};
inline MeleeSettings sanitizeMelee(MeleeSettings s){auto clamp=[](float v,float fallback,float a,float b){return std::isfinite(v)?std::clamp(v,a,b):fallback;};s.range=clamp(s.range,75,20,200);s.leadMs=clamp(s.leadMs,0,0,500);s.windupMs=clamp(s.windupMs,100,0,500);s.offsetMs=clamp(s.offsetMs,0,-250,250);return s;}
inline bool sameMelee(const MeleeSettings& a,const MeleeSettings& b){return a.enabled==b.enabled&&a.includeArrivalAge==b.includeArrivalAge&&a.range==b.range&&a.leadMs==b.leadMs&&a.windupMs==b.windupMs&&a.offsetMs==b.offsetMs;}
inline MeleeSettings readMeleeSettings(const nlohmann::json& root){MeleeSettings s;if(!root.contains("tankRockMelee")||!root["tankRockMelee"].is_object())return s;const auto& j=root["tankRockMelee"];auto number=[&](const char* k,float d){return j.contains(k)&&j[k].is_number()?j[k].get<float>():d;};s.range=number("range",75);s.leadMs=number("leadMs",0);s.windupMs=number("windupMs",100);s.offsetMs=number("offsetMs",0);if(j.contains("includeArrivalAge")&&j["includeArrivalAge"].is_boolean())s.includeArrivalAge=j["includeArrivalAge"].get<bool>();if(j.contains("drawRay")&&j["drawRay"].is_boolean())s.drawRay=j["drawRay"].get<bool>();return sanitizeMelee(s);}
inline void writeMeleeSettings(nlohmann::json& root,const MeleeSettings& raw){auto s=sanitizeMelee(raw);root["tankRockMelee"]={{"range",s.range},{"leadMs",s.leadMs},{"windupMs",s.windupMs},{"offsetMs",s.offsetMs},{"includeArrivalAge",s.includeArrivalAge},{"drawRay",s.drawRay}};}
struct SegmentHit {bool intersects=false;float entry=0,exit=0;};
inline SegmentHit meleeSegmentBox(Vec3 eye,Vec3 direction,float range,Vec3 center,float half){
 SegmentHit out;if(!valid(eye)||!valid(center)||!valid(direction,2)||!std::isfinite(range)||range<=0||range>200||!std::isfinite(half)||half<4||half>64||dango::length(direction)<.5f)return out;direction=dango::normalize(direction);float first=0,last=range;float o[]={eye.x,eye.y,eye.z},d[]={direction.x,direction.y,direction.z},c[]={center.x,center.y,center.z};
 for(unsigned i=0;i<3;++i){float lo=c[i]-half,hi=c[i]+half;if(std::abs(d[i])<1e-6f){if(o[i]<lo||o[i]>hi)return out;continue;}float a=(lo-o[i])/d[i],b=(hi-o[i])/d[i];if(a>b)std::swap(a,b);first=std::max(first,a);last=std::min(last,b);if(first>last)return out;}
 return {true,first,last};
}
struct MeleeResult {uint32_t handle=0;bool valid=false,inRangeNow=false,canSkeet=false;Vec3 predicted{};float horizonMs=0,entryDistance=0,sampleAgeMs=0;bool worldImpactKnown=false;const char* reason="no motion sample";};
struct MeleeTransition {uint32_t handle=0;bool entered=false;const char* reason="geometry changed";};
struct MeleeFrame {bool enabled=false,poseValid=false;uint32_t epoch=0,revision=0;uint64_t tick=0,entries=0,exits=0;MeleeSettings settings;Vec3 eye{},forward{},rayEnd{};float halfSize=16;std::map<uint32_t,MeleeResult> results;std::vector<MeleeTransition> transitions;};
class MeleeTracker {
 uint32_t epoch_=0,revision_=0;uint64_t entries_=0,exits_=0;MeleeSettings previousSettings_;float previousHalf_=-1;std::map<uint32_t,bool> previous_;
public:
 void reset(){previous_.clear();previousHalf_=-1;entries_=exits_=0;}
 MeleeFrame evaluate(uint32_t epoch,uint64_t now,const std::map<uint32_t,Track>& tracks,const dango::CameraPose* pose,MeleeSettings settings,float half,const std::map<uint32_t,Landing>& landings){
  settings=sanitizeMelee(settings);if(epoch_!=epoch){reset();epoch_=epoch;}
  if(!sameMelee(settings,previousSettings_)||previousHalf_!=half){previous_.clear();++revision_;previousSettings_=settings;previousHalf_=half;}
  MeleeFrame out;out.epoch=epoch;out.tick=now;out.settings=settings;out.enabled=settings.enabled;out.revision=revision_;out.halfSize=half;
  if(!settings.enabled){previous_.clear();out.entries=entries_;out.exits=exits_;return out;}
  out.poseValid=pose&&valid(pose->eye)&&valid(pose->forward,2)&&dango::length(pose->forward)>.5f;if(out.poseValid){out.eye=pose->eye;out.forward=dango::normalize(pose->forward);out.rayEnd=out.eye+out.forward*settings.range;}
  std::map<uint32_t,bool> current;
  for(const auto& item:tracks){const auto& t=item.second;MeleeResult r;r.handle=item.first;
   if(!out.poseValid)r.reason="camera pose unavailable";
   else if(t.state!=State::ReleasedInferred&&t.state!=State::FlyingInferred)r.reason="not an observed unparented flight";
   else if(t.history.empty())r.reason="no motion sample";
   else{const auto& sample=t.history.back();if(now<sample.wallMs||now-sample.wallMs>250)r.reason="stale motion sample";
    else{r.sampleAgeMs=float(now-sample.wallMs);r.horizonMs=std::clamp(settings.leadMs+settings.windupMs+settings.offsetMs+(settings.includeArrivalAge?r.sampleAgeMs:0),0.f,1500.f);
     if(r.horizonMs>0&&(!sample.velocityValid||!t.gravityValid))r.reason="prediction requires valid velocity and gravity";
     else{r.valid=true;r.predicted=ballistic(sample.position,sample.velocity,t.gravityValid?t.gravity:0,r.horizonMs/1000);r.inRangeNow=meleeSegmentBox(out.eye,out.forward,settings.range,sample.position,half).intersects;auto intersect=meleeSegmentBox(out.eye,out.forward,settings.range,r.predicted,half);r.canSkeet=intersect.intersects;r.entryDistance=intersect.entry;r.reason=r.canSkeet?"assumed box intersects finite aim ray":"outside finite aim ray";
      auto hit=landings.find(item.first);if(hit!=landings.end()&&hit->second.valid()&&now>=hit->second.computedMs&&now-hit->second.computedMs<=250){r.worldImpactKnown=true;float targetAge=float(now-hit->second.sampleMs)/1000;float futureFromNow=r.horizonMs/1000-r.sampleAgeMs/1000;if(targetAge+futureFromNow>=hit->second.seconds){r.canSkeet=false;r.reason="target at or after predicted world impact";}}
     }
    }
   }
   bool was=previous_.count(item.first)&&previous_.at(item.first);if(was!=r.canSkeet){out.transitions.push_back({item.first,r.canSkeet,r.reason});if(r.canSkeet)++entries_;else ++exits_;}current[item.first]=r.canSkeet;out.results.emplace(item.first,r);
  }
  for(const auto& old:previous_)if(old.second&&!current.count(old.first)){out.transitions.push_back({old.first,false,"entity disappeared / state reset"});++exits_;}
  previous_=std::move(current);out.entries=entries_;out.exits=exits_;return out;
 }
};
}
