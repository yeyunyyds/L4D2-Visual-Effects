Source base: dfb73d9. Matched experimental DLL SHA256: 4f35e80ee893c9a73850bdf313b6bc4bfb46e69e8809c671193ac2f8b9cadb2a
Run bash scripts/test.sh; build using MinGW x86 via scripts/build-mingw.sh.
This environment used official Debian MinGW GCC12 and -Wno-error=array-bounds for seven preexisting vendored ImGui warnings. No game validation. See docs/experiments/tank-rock.md.
