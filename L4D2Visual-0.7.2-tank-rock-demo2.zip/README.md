# L4D2Visual 0.7.2 Tank 石头实验 demo2

根据 demo1 未发现实体的日志改进的 Windows x86 / L4N v2 实验插件。demo2 新路径仍待实机验证。基于 0.7.2，不包含后续 0.7.4 或 0.8.0 预览的功能变更。游戏内主版本名称仍显示 0.7.2，实验子菜单标题应为“Tank 石头实验 demo2”。

**尚未真实游戏验证。联机功能未经测试，不保障 VAC 安全。**

## 安装与测试

1. 完整退出游戏，备份当前插件 DLL 和 L4D2Visual/hud.json。
2. 将 bin 合并到游戏根目录，确保只有一份 bin/neko/plugins/L4D2Visual.dll。本包不包含 hud.json，不覆盖个人配置。
3. 打开 L4N → L4D2Visual → Tank 石头实验；菜单通过 - / = 翻页，0 返回。
4. 开启 A 实体识别、B 高频运动采样。让 Tank 投石，观察实体状态与位置标记。共享类需关联 Tank thrower/owner 才接纳为推断石头；其他候选橙色标注 UNCONFIRMED，不生成轨迹。
5. 开启 C 轨迹预测，并显式开启“实验重力参数授权”（默认候选值 800，仅实验参数），或启用“观测重力校准”；未取得有效重力时不生成预测。
6. 可开启“后台诊断 JSONL”，记录位于 bin/neko/plugins/L4D2Visual/tank-rock.jsonl。复现结束后关闭日志，并保留日志用于排查。新日志应包含 schema=2、build=tank-rock-demo2，可记录未发现原因和未确认候选。
7. 实验开关和日志默认关闭、不跨会话保存。颜色、透明度等外观可通过主菜单保存设置。

## 已知限制

客户端类、parent 语义、坐标空间和实际精度仍待实测。直接速度/模拟时间字段可能不可用，此时以明确标注的到达时间/位置差分估计。全实体发现周期仍为 200 ms，短寿命石头可能漏掉。轨迹是理论抛物线，没有地图碰撞截断或绝对网络延迟补偿；没有自动挥刀或攻击指令。

针对 demo1 空列表问题的报告见 bin/neko/plugins/L4D2Visual/experiments/tank-rock-demo2.md。详细实验报告与验证记录见 bin/neko/plugins/L4D2Visual/experiments/。同目录含日志分析工具，使用 Python 3 运行。本下载目录另有匹配源码包。

DLL SHA256: 2463dadd189c37598c32c728270c2b874c696515cc34b36329b304f33136c70e
