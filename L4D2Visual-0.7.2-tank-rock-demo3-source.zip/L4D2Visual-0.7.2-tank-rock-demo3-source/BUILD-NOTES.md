Source base: dfb73d9. Matched experimental DLL SHA256: c8b112766a1d29f6c1001486238c8605d0ae862574fb7c0d726b7d5f5e82c4ef
Run bash scripts/test.sh; build using MinGW x86 via scripts/build-mingw.sh.
This environment used official Debian MinGW GCC12 and -Wno-error=array-bounds for seven preexisting vendored ImGui warnings. No game validation. See docs/experiments/tank-rock.md.
