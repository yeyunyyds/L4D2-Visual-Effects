#pragma once
#include "dango/entity_inventory.hpp"
#include "special_infected.hpp"
namespace visual::rocks {
enum class Identity {None,DedicatedClass,TankOwnedSharedProjectile};
inline bool rockClass(const std::string& name){return name=="CTankRock"||name=="TankRock";}
inline bool sharedProjectileClass(const std::string& name){return name=="CBaseCSGrenadeProjectile";}
inline bool validIdentity(const dango::inventory::Record& r){return r.index<2048&&r.handle!=0xffffffffu&&r.serial==(r.handle>>12)&&(r.handle&4095u)==r.index;}
struct Identification {Identity kind=Identity::None;uint32_t actorHandle=0xffffffffu;const char* reason="not a rock class";};
inline Identification identifyRock(const dango::inventory::Record& r,const dango::inventory::Frame& frame){
 if(!validIdentity(r))return {Identity::None,0xffffffffu,"invalid projectile handle / serial"};
 if(rockClass(r.className))return {Identity::DedicatedClass,0xffffffffu,"dedicated client class"};
 if(!sharedProjectileClass(r.className))return {};
 // A known thrower outranks owner. Never override a non-Tank thrower using owner.
 const auto actor=r.thrower&&*r.thrower!=0xffffffffu?r.thrower:r.owner;
 if(!actor||*actor==0xffffffffu)return {Identity::None,0xffffffffu,"shared projectile: thrower / owner unavailable"};
 for(const auto& a:frame.records)if(a.handle==*actor&&validIdentity(a)){
  if(specialCharacter(a)==specialIndex("Tank"))return {Identity::TankOwnedSharedProjectile,*actor,"shared projectile + Tank actor (rock inferred)"};
  return {Identity::None,*actor,"shared projectile: actor is not Tank"};
 }
 return {Identity::None,*actor,"shared projectile: actor handle unresolved / stale"};
}
inline const char* identityName(Identity kind){switch(kind){case Identity::DedicatedClass:return "dedicated class";case Identity::TankOwnedSharedProjectile:return "Tank-owned projectile / rock inferred";default:return "unconfirmed projectile";}}
}
