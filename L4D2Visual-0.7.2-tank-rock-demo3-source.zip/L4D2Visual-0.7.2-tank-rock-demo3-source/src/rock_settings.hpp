#pragma once
#include "dango/json.hpp"
#include <algorithm>
#include <cmath>
namespace visual::rocks {
struct DisplaySettings {bool markers=true,direction=true,trajectory=true,errors=false,landingCircle=true;float opacity=.8f,landingOpacity=.5f;unsigned color=0;};
inline DisplaySettings readDisplaySettings(const nlohmann::json& j){
 DisplaySettings s;if(!j.contains("tankRockDisplay")||!j["tankRockDisplay"].is_object())return s;
 const auto& v=j["tankRockDisplay"];
 auto boolean=[&](const char* key,bool fallback){return v.contains(key)&&v[key].is_boolean()?v[key].get<bool>():fallback;};
 s.markers=boolean("markers",true);s.direction=boolean("direction",true);s.trajectory=boolean("trajectory",true);s.errors=boolean("errors",false);s.landingCircle=boolean("landingCircle",true);
 if(v.contains("landingOpacity")&&v["landingOpacity"].is_number()){float a=v["landingOpacity"].get<float>();if(std::isfinite(a))s.landingOpacity=std::clamp(a,.1f,.8f);}
 if(v.contains("opacity")&&v["opacity"].is_number()){float a=v["opacity"].get<float>();if(std::isfinite(a))s.opacity=std::clamp(a,.1f,1.f);}
 if(v.contains("color")&&v["color"].is_number_integer()){int c=v["color"].get<int>();s.color=unsigned(std::clamp(c,0,2));}
 return s;
}
inline void writeDisplaySettings(nlohmann::json& j,const DisplaySettings& s){j["tankRockDisplay"]={{"markers",s.markers},{"direction",s.direction},{"trajectory",s.trajectory},{"errors",s.errors},{"opacity",s.opacity},{"color",s.color},{"landingCircle",s.landingCircle},{"landingOpacity",s.landingOpacity}};}
}
