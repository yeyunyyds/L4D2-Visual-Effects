#pragma once
#include "dango/source_entities.hpp"
#include "rock_tracker.hpp"
#include "rock_landing.hpp"
#include "image_trace.hpp"
#include <deque>
#include <mutex>
namespace visual::rockruntime {
inline std::shared_ptr<const rocks::Options> options=std::make_shared<const rocks::Options>();
inline std::atomic<bool> diagnostics{false},faulted{false};
inline std::atomic<const char*> status{"Tank rock experiments off"};
struct Candidate {source_entities::Record record;rocks::Identification identification;};
struct Discovery {uint32_t epoch=0;uint64_t tick=0;unsigned records=0,occupied=0,unknownClass=0,unknownBase=0,unknownTables=0;std::string status;std::map<std::string,unsigned> observedClasses;std::vector<Candidate> candidates;std::map<std::string,source_entities::wire::Fields> schemas;std::map<std::string,std::string> simulationProxyHints;};
struct Snapshot {uint32_t epoch=0;uint64_t tick=0;std::map<uint32_t,rocks::Track> tracks;uint64_t droppedLogs=0;std::vector<rocks::Event> events;std::optional<dango::Vec3> viewerEye;std::shared_ptr<const Discovery> discovery;bool discoveryChanged=false;rocks::Options requested;std::map<uint32_t,rocks::Landing> landings;std::string landingStatus;};
inline std::shared_ptr<const Snapshot> snapshot=std::make_shared<const Snapshot>();
inline rocks::Tracker tracker;
inline float previousLandingGravity=-1;inline bool previousLandingFit=false,previousLandingAuthorization=false;
inline picturetrace::Binding landingTrace;inline std::map<uint32_t,rocks::Landing> landings;inline uint64_t nextLanding=0;inline size_t landingCursor=0;inline bool collisionEnabled=false;inline std::string landingStatus="world collision experiment off";
inline void updateLandings(const rocks::Options& settings,const dango::GameCameraFrame& camera){
 if(!settings.predict||!settings.mapCollision){landings.clear();landingTrace.reset();collisionEnabled=false;landingStatus="world collision experiment off / future endpoint only";return;}
 if(previousLandingGravity!=settings.gravity||previousLandingFit!=settings.calibrateGravity||previousLandingAuthorization!=settings.experimentalGravity){landings.clear();nextLanding=0;}previousLandingGravity=settings.gravity;previousLandingFit=settings.calibrateGravity;previousLandingAuthorization=settings.experimentalGravity;
 if(!collisionEnabled){landingTrace.reset();collisionEnabled=true;nextLanding=0;}
 for(auto it=landings.begin();it!=landings.end();){auto t=tracker.tracks().find(it->first);if(t==tracker.tracks().end()||t->second.trajectory.empty()||camera.tick<it->second.computedMs||camera.tick-it->second.computedMs>250)it=landings.erase(it);else ++it;}
 if(camera.tick<nextLanding)return;nextLanding=camera.tick+50;
 if(!landingTrace.object&&!landingTrace.faulted&&!picturetrace::connectBinding(landingTrace))landingTrace.faulted=true;
 if(landingTrace.faulted){landings.clear();landingStatus="verified world trace unavailable / future endpoint only";return;}
 std::vector<const rocks::Track*> active;for(const auto& item:tracker.tracks()){const auto& t=item.second;if(!t.history.empty()&&!t.trajectory.empty()&&camera.tick>=t.history.back().wallMs&&camera.tick-t.history.back().wallMs<=250)active.push_back(&t);}
 if(active.empty()){landingStatus="waiting for valid flight";return;}
 const auto& t=*active[landingCursor++%active.size()];unsigned budget=64;auto result=rocks::predictLanding(t.history.back(),t.gravity,camera.tick,budget,[](auto a,auto b,auto& out){return picturetrace::castBinding(landingTrace,a,b,out);});landings[t.record.handle]=result;landingStatus=rocks::landingName(result.state);
}
inline bool active(){return std::atomic_load(&options)->anyEnabled();}
// One immutable frame is shared by rendering and the bounded diagnostic queue.
// JSON formatting and all file operations run exclusively in drain().
inline std::mutex logMutex;
inline std::deque<std::shared_ptr<const Snapshot>> logQueue;
inline uint64_t droppedLogs=0;
inline std::shared_ptr<const source_entities::Frame> inventory;
inline uint32_t epoch=0;inline bool running=false;inline uint64_t lastCaptureTick=0,lastLogTick=0;
inline std::shared_ptr<const Discovery> discovery;
inline std::shared_ptr<const Discovery> inspectDiscovery(const source_entities::Frame& f){
 auto d=std::make_shared<Discovery>();d->epoch=f.epoch;d->tick=f.tick;d->records=unsigned(f.records.size());d->occupied=f.occupied;d->unknownClass=f.unknownClass;d->unknownBase=f.unknownBase;d->unknownTables=f.unknownTables;d->status=f.status;
 for(const auto& r:f.records){++d->observedClasses[r.className];if(rocks::sharedProjectileClass(r.className)&&d->candidates.size()<64)d->candidates.push_back({r,rocks::identifyRock(r,f)});}
 if(diagnostics)for(const auto& c:source_entities::classes)if(rocks::sharedProjectileClass(c.second.name)||rocks::rockClass(c.second.name)){d->schemas[c.second.name]=c.second.fields;if(!c.second.simulationProxyHint.empty())d->simulationProxyHints[c.second.name]=c.second.simulationProxyHint;}
 return d;
}
inline std::optional<source_entities::Record> directed(uint32_t handle,const dango::GameCameraFrame& camera,bool& identityGone){
 using namespace source_entities;
 if(!bound||source_entities::faulted||!list)return {};
 unsigned index=handle&4095u;if(index>=source_entities::profile::MaxNetworked)return {};
 uint32_t object=uint32_t(reinterpret_cast<uintptr_t>(list));
 auto entries=uint32_t(int64_t(object)+source_entities::profile::EntryBaseDelta);
 wire::Entry entry{};uint32_t net=0;
 if(!wire::load(reader,entries+index*sizeof(entry),entry))return {};
 if(!entry.entity||entry.serial!=(handle>>12)){identityGone=true;return {};}
 if(!wire::load(reader,object+source_entities::profile::CacheOffset+index*8,net)||!net)return {};
 Frame frame;frame.epoch=camera.epoch;frame.tick=camera.tick;
 auto record=readRecord(index,entry,net,frame);
 // Revalidate after the read: reject entity reuse during a sample.
 wire::Entry after{};
 if(!record||!wire::load(reader,entries+index*sizeof(after),after)||after.entity!=entry.entity||after.serial!=entry.serial)return {};
 return record;
}
inline void onFrame(const dango::GameCameraFrame& camera)noexcept{
 try{
 auto settings=std::atomic_load(&options);
 if(!settings->anyEnabled()||!camera.active){
  if(running){if(diagnostics){auto reset=std::make_shared<Snapshot>();reset->epoch=camera.epoch;reset->tick=camera.tick;rocks::Event e;e.wallMs=camera.tick;e.reason="camera inactive / experiments off: tracker reset";reset->events.push_back(e);std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock()){if(logQueue.size()>=64)logQueue.pop_front();logQueue.push_back(reset);}}tracker.reset(camera.epoch);std::atomic_store(&snapshot,std::make_shared<const Snapshot>());inventory.reset();}
  running=false;landings.clear();landingTrace.reset();collisionEnabled=false;discovery.reset();lastCaptureTick=lastLogTick=0;faulted=false;status="Tank rock experiments off / camera inactive";return;
 }
 if(faulted)return;
 if(running&&epoch==camera.epoch&&lastCaptureTick==camera.tick)return;lastCaptureTick=camera.tick;
 bool changedEpoch=running&&epoch!=camera.epoch;
 if(!running||epoch!=camera.epoch){tracker.reset(camera.epoch);landings.clear();landingTrace.reset();collisionEnabled=false;inventory.reset();epoch=camera.epoch;running=true;}
 auto effective=*settings;effective.diagnostics=diagnostics.load();tracker.configure(effective);
 auto latest=std::atomic_load(&source_entities::snapshot);bool inventoryChanged=false;
 if(latest!=inventory){inventory=latest;if(latest->epoch==camera.epoch&&camera.tick>=latest->tick&&camera.tick-latest->tick<=500){tracker.discover(*latest);discovery=inspectDiscovery(*latest);inventoryChanged=true;}}
 std::vector<uint32_t> handles;for(const auto& item:tracker.tracks()){if(item.second.state==rocks::State::Destroyed)continue;if(handles.size()>=64)break;handles.push_back(item.first);}
 for(auto handle:handles){bool gone=false;auto record=directed(handle,camera,gone);if(record)tracker.observe(*record,camera.tick);else if(gone)tracker.missing(handle,camera.tick);else tracker.readFailure(handle,camera.tick);}
 tracker.expire(camera.tick);updateLandings(effective,camera);
 auto frame=std::make_shared<Snapshot>();frame->epoch=camera.epoch;frame->tick=camera.tick;frame->tracks=tracker.tracks();frame->landings=landings;frame->landingStatus=landingStatus;frame->requested=effective;frame->discovery=discovery;frame->discoveryChanged=inventoryChanged;frame->droppedLogs=droppedLogs;auto events=tracker.takeEvents();if(diagnostics)frame->events=std::move(events);dango::CameraPose pose;if(dango::cameraPose(camera,pose))frame->viewerEye=pose.eye;if(changedEpoch&&diagnostics){rocks::Event e;e.wallMs=camera.tick;e.reason="map epoch changed: previous tracker state cleared";frame->events.push_back(e);}
 std::shared_ptr<const Snapshot> published=frame;std::atomic_store(&snapshot,published);
 if(diagnostics&&(inventoryChanged||!frame->events.empty()||camera.tick-lastLogTick>=100)){lastLogTick=camera.tick;std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock()){if(logQueue.size()>=64){logQueue.pop_front();++droppedLogs;}logQueue.push_back(published);}else ++droppedLogs;}
 else if(!diagnostics){std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock())logQueue.clear();}
 status="demo3: g=320 experimental; proxy probe untrusted; optional world ray impact";
 }catch(...){faulted=true;status="Rock module disabled after exception; toggle experiments off to reset";std::atomic_store(&snapshot,std::make_shared<const Snapshot>());}
}
inline void drain(const std::filesystem::path& directory){
 std::deque<std::shared_ptr<const Snapshot>> frames;
 {std::lock_guard<std::mutex> lock(logMutex);frames.swap(logQueue);}
 if(!diagnostics||frames.empty())return;
 try{
 std::filesystem::create_directories(directory);
 auto path=directory/L"tank-rock.jsonl";
 if(std::filesystem::exists(path)&&std::filesystem::file_size(path)>16*1024*1024){auto previous=directory/L"tank-rock.previous.jsonl";std::filesystem::remove(previous);std::filesystem::rename(path,previous);}
 std::ofstream file(path,std::ios::binary|std::ios::app);
 for(const auto& frame:frames){
  nlohmann::json out={{"schema",3},{"build","tank-rock-demo3"},{"epoch",frame->epoch},{"wall_ms",frame->tick},{"dropped_log_frames",frame->droppedLogs},{"space","network_origin_unparented_only"},{"trajectory_kind","theoretical_no_collision_no_latency_compensation"},{"rocks",nlohmann::json::array()}};
  if(frame->viewerEye)out["viewer_eye"]={frame->viewerEye->x,frame->viewerEye->y,frame->viewerEye->z};
  out["absolute_network_latency_known"]=false;
  out["options"]={{"identify",frame->requested.identify},{"sample",frame->requested.sample},{"predict",frame->requested.predict},{"experimental_gravity",frame->requested.gravity},{"gravity_authorized",frame->requested.experimentalGravity},{"gravity_fit_enabled",frame->requested.calibrateGravity},{"map_collision",frame->requested.mapCollision}};
  out["landing_status"]=frame->landingStatus;out["landings"]=nlohmann::json::array();for(const auto& pair:frame->landings){const auto& p=pair.second;out["landings"].push_back({{"handle",pair.first},{"status",rocks::landingName(p.state)},{"sample_ms",p.sampleMs},{"computed_ms",p.computedMs},{"seconds",p.seconds},{"position",{p.position.x,p.position.y,p.position.z}},{"normal",{p.normal.x,p.normal.y,p.normal.z}},{"rays",p.rays},{"static_world_only",true},{"projectile_hull",false}});}
  if(frame->discovery){const auto& d=*frame->discovery;out["discovery"]={{"epoch",d.epoch},{"tick",d.tick},{"records",d.records},{"occupied",d.occupied},{"unknown_class",d.unknownClass},{"unknown_base",d.unknownBase},{"unknown_tables",d.unknownTables},{"status",d.status}};
   if(frame->discoveryChanged){out["discovery"]["observed_classes"]=d.observedClasses;out["discovery"]["simulation_proxy_hints"]=d.simulationProxyHints;out["discovery"]["candidate_fields"]=nlohmann::json::object();for(const auto& cls:d.schemas)for(const auto& field:cls.second)out["discovery"]["candidate_fields"][cls.first][field.first]={{"offset",field.second.offset},{"type",field.second.type}};}
   out["unconfirmed_projectiles"]=nlohmann::json::array();for(const auto& c:d.candidates){const auto& r=c.record;if(c.identification.kind!=rocks::Identity::None)continue;nlohmann::json candidate={{"handle",r.handle},{"serial",r.serial},{"index",r.index},{"class",r.className},{"model",r.modelName},{"reason",c.identification.reason},{"actor_handle",c.identification.actorHandle}};if(r.owner)candidate["owner"]=*r.owner;if(r.thrower)candidate["thrower"]=*r.thrower;if(r.parent)candidate["parent"]=*r.parent;if(r.modelIndex)candidate["model_index"]=*r.modelIndex;if(r.networkOrigin)candidate["network_origin"]={r.networkOrigin->x,r.networkOrigin->y,r.networkOrigin->z};out["unconfirmed_projectiles"].push_back(std::move(candidate));}
  }
  for(const auto& item:frame->tracks){const auto& track=item.second;auto r=track.record;
   nlohmann::json value={{"handle",r.handle},{"serial",r.serial},{"index",r.index},{"class",r.className},{"model",r.modelName},{"state",int(track.state)},{"state_name",rocks::stateName(track.state)}};
   value["identification"]=rocks::identityName(track.identity);value["actor_handle"]=track.actorHandle;if(r.owner)value["owner"]=*r.owner;if(r.thrower)value["thrower"]=*r.thrower;
   if(r.networkOrigin)value["network_origin"]={r.networkOrigin->x,r.networkOrigin->y,r.networkOrigin->z};
   if(r.velocity)value["network_velocity"]={r.velocity->x,r.velocity->y,r.velocity->z};
   if(r.simulationTime)value["simulation_time"]=*r.simulationTime;if(r.simulationTimeProbe){value["unverified_simulation_time_storage"]=*r.simulationTimeProbe;value["proxy_probe_is_trusted_clock"]=false;}
   if(r.parent)value["parent"]=*r.parent;
   if(frame->viewerEye&&!track.history.empty())value["distance_to_eye"]=dango::length(track.history.back().position-*frame->viewerEye);
   value["created_ms"]=track.createdMs;value["last_seen_ms"]=track.lastSeenMs;value["destroyed_ms"]=track.destroyedMs;
   value["metrics"]={{"reads",track.metrics.reads},{"updates",track.metrics.updates},{"repeats",track.metrics.repeats},{"invalid",track.metrics.invalid},{"read_failures",track.metrics.readFailures},{"gaps_over_50ms",track.metrics.gaps},{"simulation_interval_ms",track.metrics.intervalMs},{"arrival_interval_ms",track.metrics.arrivalMs},{"relative_delay_ms",track.metrics.relativeDelayMs}};
   value["gravity"]={{"value",track.gravity},{"valid",track.gravityValid},{"calibrated",track.gravityCalibrated},{"fits",track.gravityFits},{"fit_uses_simulation_clock",track.gravitySimulationClock},{"source",track.gravityCalibrated?(track.gravitySimulationClock?"simulation_velocity_fit":"arrival_velocity_fit_estimate"):"authorized_experimental_parameter"}};
   value["confidence_heuristic"]=track.confidence;value["error_stats"]=nlohmann::json::array();
   for(size_t i=0;i<track.errors.size();++i){const auto& e=track.errors[i];value["error_stats"].push_back({{"horizon_s",rocks::Horizons[i]},{"count",e.count},{"mean",e.mean()},{"rms",e.rms()},{"max",e.max},{"speed_sum",e.speedSum},{"interval_sum",e.intervalSum},{"arrival_age_sum",e.arrivalAgeSum}});}
   out["rocks"].push_back(std::move(value));
  }
  out["events"]=nlohmann::json::array();
  for(const auto& e:frame->events)out["events"].push_back({{"wall_ms",e.wallMs},{"handle",e.handle},{"reason",e.reason},{"state_time",e.sample.simulationTime},{"clock_source",e.sample.simulationClock?"network_simulation":"wall_clock_fallback"},{"position",{e.sample.position.x,e.sample.position.y,e.sample.position.z}},{"velocity",{e.sample.velocity.x,e.sample.velocity.y,e.sample.velocity.z}},{"velocity_source",int(e.sample.source)},{"velocity_valid",e.sample.velocityValid},{"target_state_time",e.targetTime},{"predicted",{e.predicted.x,e.predicted.y,e.predicted.z}},{"actual_interpolated",{e.actual.x,e.actual.y,e.actual.z}},{"error",e.error}});
  file<<out.dump(-1,' ',false,nlohmann::json::error_handler_t::replace)<<'\n';
 }
 if(!file)throw std::runtime_error("rock diagnostic write failed");
 }catch(...){diagnostics=false;status="Rock diagnostic output failed; logging disabled";}
}
}
