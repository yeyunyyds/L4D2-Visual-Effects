#pragma once
#include "rock_tracker.hpp"
#include "dango/source_trace_contract.hpp"
namespace visual::rocks {
enum class LandingState {Unavailable,NoHit,Impact,StartSolid,BudgetExhausted,Invalid};
inline const char* landingName(LandingState s){switch(s){case LandingState::Impact:return "world ray impact estimate";case LandingState::NoHit:return "no world hit within 3s";case LandingState::StartSolid:return "ray starts inside solid";case LandingState::BudgetExhausted:return "trace budget exhausted";case LandingState::Invalid:return "invalid trace / motion";default:return "verified trace unavailable";}}
struct Landing {LandingState state=LandingState::Unavailable;Vec3 position{},normal{};float seconds=0;uint64_t sampleMs=0,computedMs=0;unsigned rays=0;bool valid()const{return state==LandingState::Impact;}};
inline Vec3 ballistic(Vec3 p,Vec3 v,float g,float t){return p+v*t+Vec3{0,0,-g}*(.5f*t*t);}
template<class Cast> Landing predictLanding(const Sample& sample,float gravity,uint64_t now,unsigned& budget,Cast cast){
 Landing out;out.sampleMs=sample.wallMs;out.computedMs=now;
 if(!sample.velocityValid||!valid(sample.position)||!valid(sample.velocity,20000)||!std::isfinite(gravity)||gravity<0||gravity>4000){out.state=LandingState::Invalid;return out;}
 Vec3 start=sample.position;
 for(unsigned i=1;i<=60;++i){if(!budget){out.state=LandingState::BudgetExhausted;return out;}--budget;++out.rays;float t=i*.05f;Vec3 end=ballistic(sample.position,sample.velocity,gravity,t);if(!valid(end)){out.state=LandingState::Invalid;return out;}dango::trace::Result hit;
  if(!cast(start,end,hit)){out.state=LandingState::Unavailable;return out;}
  if(!dango::trace::valid(hit,start,end)){out.state=LandingState::Invalid;return out;}
  if(hit.startSolid||hit.allSolid){out.state=LandingState::StartSolid;return out;}
  if(hit.fraction<1){if(!dango::trace::wallHit(hit)){out.state=LandingState::Invalid;return out;}out.state=LandingState::Impact;out.position=hit.end;out.normal=hit.plane.normal;out.seconds=(i-1+hit.fraction)*.05f;return out;}
  start=end;
 }
 out.state=LandingState::NoHit;return out;
}
inline std::array<Vec3,32> landingDisk(Vec3 center,Vec3 normal,float radius=32){
 normal=dango::normalize(normal);Vec3 reference=std::abs(normal.z)>.9f?Vec3{1,0,0}:Vec3{0,0,1};
 auto cross=[](Vec3 a,Vec3 b){return Vec3{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};};
 auto x=dango::normalize(cross(normal,reference)),y=cross(normal,x);std::array<Vec3,32> ring{};
 for(unsigned i=0;i<ring.size();++i){float angle=6.28318530718f*i/ring.size();ring[i]=center+normal*1.f+x*(radius*std::cos(angle))+y*(radius*std::sin(angle));}return ring;
}
inline float nextExperimentalGravity(float current){constexpr float values[]={240,280,300,320,340,360,400,600,800,1000,1200};for(float g:values)if(g>current+.01f)return g;return values[0];}
}
