# Tank 石头实验 demo2：未发现实体的排查与兼容尝试

## 已确认的日志事实

用户提供的 demo1 实机日志中，约 84.6 秒内记录 18,718 个日志帧，`rocks` 和 `events` 全为空。实体绑定成功，普通实体扫描正常。该次游戏会话的周期实体摘要从未出现 demo1 接受的 `CTankRock` / `TankRock`，而多次出现 `CBaseCSGrenadeProjectile`。模型读取不可用（`modelLookup=0`），不会退回未经验证的模型接口。

这能确认 demo1 没有接纳任何石头实体，并且专用类假设在这份日志中不成立。**不能仅据此证明 CBaseCSGrenadeProjectile 就是石头**：旧日志没有投掷者、所有者及候选字段，普通手雷也可能使用共享类。

本报告只保存上述必要汇总，不公开用户上传的原始游戏日志。

## demo2 行为

- 保留专用客户端类识别。
- 新增共享类 `CBaseCSGrenadeProjectile` 的受控兼容路径：优先读取 `m_hThrower`，不可用或无效时读取 `m_hOwnerEntity`。通过完整 handle/serial 在当前实体快照中解析该角色，必须识别为 NPC Tank 或 team=3/zombieClass=8 的玩家 Tank，才接纳为 **Tank-owned projectile / rock inferred**。
- 投掷者为已知非 Tank 时，不使用 owner 覆盖它。无法解析、serial 复用和普通玩家手雷均不接纳；不依据共享类名或距离直接判定石头。
- 这仍是推断：模组可让 Tank 拥有其他投射物；不宣称已确认实体类型。HUD 和日志展示识别依据，预测置信启发式分数上限 0.25，不能解释为统计概率。
- 不能接纳的共享投射物保留为独立候选，菜单列出 handle/serial 和拒绝原因。若父关系明确为未挂接且位置有效，可显示橙色 `UNCONFIRMED projectile` 标记；不生成石头预测。候选最多 64 个、只复用 200 ms 快照，不增加全实体扫描频率。
- 父关系、坐标空间、模拟时间和速度的安全门槛保持不变。新增 `m_hThrower` 只从校验的 RecvTable 读取 DPT_Int handle，不猜字段偏移、不调用新虚函数。
- 同毫秒的重复相机回调不重复采样。无事件日志节流到 100 ms 或新的全实体快照；有新样本/预测/误差的事件保留原路径。后台队列和文件大小仍受限。

## 诊断 schema 2

沿用 `tank-rock.jsonl` 文件名，加入 build=`tank-rock-demo2`。保留 schema1 误差事件字段，离线分析工具继续兼容。

新增 `options`、`discovery`（快照 epoch/tick、records/occupied、unknown_class/base/tables、状态）；新清单到达时记录 observed_classes 和候选类的可用字段类型/偏移。`unconfirmed_projectiles` 记录候选身份、模型索引、owner/thrower/parent、原始位置及拒绝原因。已接纳记录含 identification 与 actor_handle。

只有空 rocks 时，仍可判断：

1. discovery.records=0 或状态报错：基础清单问题。
2. 未出现共享/专用类：可能发现延迟、短寿命实体遗漏或类假设仍不适用。
3. 有 unconfirmed_projectiles：检查 reason 与 owner/thrower 字段。
4. 已有 rocks 但没有样本：检查 parent、坐标、模拟时间/回退与失败原因。

## 再次实机测试

退出游戏后备份 DLL 和 hud.json，替换 demo2。菜单标题应为“Tank 石头实验 demo2”，不要同时加载两份 DLL。开启 A/B/C、实验重力授权和后台诊断，让 Tank 连续投石数次。若没有轨迹，提供新 `tank-rock.jsonl`（以及有轮换时的 `tank-rock.previous.jsonl`）。新文件应包含 schema2/build 标记。

**demo2 编译和离线测试不代表上述推断路径已在游戏验证成功。** 不实现自动挥刀，不修改服务器状态，没有地图碰撞截断或绝对网络延迟补偿。基于 0.7.2，不包含后续 0.7.4 / 0.8.0 预览的功能变更；项目原有 VAC 与兼容性声明继续适用。

## 本次离线验证

`bash scripts/test.sh` 退出码 0：19 个 C++ 测试程序通过 ASan/UBSan，3 项 Python 测试通过。新增共享类识别测试覆盖缺失 owner/thrower、NPC Tank、玩家 Tank、非 Tank、thrower 优先级、serial 复用、类改变拒绝和置信分数上限。字段测试新增真实 `m_hThrower` 白名单和继承偏移。

Windows x86 交叉编译退出码 0，PE32 Intel i386。沿用已记录的 GCC12 原有 ImGui array-bounds 警告降级；未新增未经验证的接口。DLL SHA256：`2463dadd189c37598c32c728270c2b874c696515cc34b36329b304f33136c70e`。完整输出见 `tank-rock-demo2-validation.txt`。
