import importlib.util
import json
import pathlib
import unittest
spec = importlib.util.spec_from_file_location('rock_log', pathlib.Path(__file__).parents[1] / 'scripts/analyze-rock-log.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class LogTest(unittest.TestCase):
    def test_backfill_and_correlations(self):
        lines = []
        for i in range(1, 5):
            pred = dict(reason='prediction', handle=1, target_state_time=i + .1, state_time=i,
                        predicted=[i, 0, 0], velocity=[i * 10, 0, 0], clock_source='network_simulation')
            error = dict(pred, reason='error (simulation-time interpolated observation)', error=i)
            lines.append(json.dumps(dict(epoch=1, rocks=[dict(handle=1, distance_to_eye=i * 20,
                             metrics=dict(simulation_interval_ms=i, relative_delay_ms=i * 2))], events=[pred, error])))
        out = module.analyze(lines + ['malformed'])
        group = out['groups'][0]
        self.assertEqual(group['horizon_ms'], 100)
        self.assertEqual(group['count'], 4)
        self.assertAlmostEqual(group['rms'], (30 / 4) ** .5)
        self.assertAlmostEqual(group['correlations']['speed']['pearson_r'], 1)
        self.assertEqual(out['malformed_lines'], 1)
        self.assertFalse(out['absolute_network_latency_available'])

    def test_ambiguous_prediction_is_skipped(self):
        p = dict(reason="prediction", handle=1, target_state_time=.1, state_time=0,
                 predicted=[0, 0, 0], velocity=[1, 0, 0], clock_source="network_simulation")
        e = dict(p, reason="error (simulation-time interpolated observation)", error=0)
        out = module.analyze([json.dumps(dict(epoch=1, events=[p, p, e]))])
        self.assertEqual(out["groups"], [])
        self.assertEqual(out["ambiguous_predictions"], 1)

    def test_epoch_and_missing_predictions(self):
        e = dict(reason='error (wall-time interpolated estimate)', handle=1,
                 target_state_time=.1, predicted=[0, 0, 0], error=2)
        out = module.analyze([json.dumps(dict(epoch=2, events=[e]))])
        self.assertEqual(out['groups'], [])
        self.assertEqual(out['unmatched_error_events'], 1)
        self.assertIsNone(module.correlation([(1, 1), (1, 2), (1, 3)]))

if __name__ == '__main__':
    unittest.main()
