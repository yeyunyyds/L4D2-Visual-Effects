#include "rock_tracker.hpp"
#include <cassert>
#include <iostream>
using namespace visual::rocks;
using dango::inventory::Record;
Record rec(unsigned i,unsigned serial,const char* cls){Record r;r.index=i;r.serial=serial;r.handle=(serial<<12)|i;r.className=cls;return r;}
int main(){
 auto tank=rec(4,2,"Tank");auto grenade=rec(8,5,"CBaseCSGrenadeProjectile");dango::inventory::Frame f;f.epoch=1;f.tick=100;f.records={tank,grenade};
 assert(identifyRock(grenade,f).kind==Identity::None);
 grenade.owner=tank.handle;f.records={tank,grenade};assert(identifyRock(grenade,f).kind==Identity::TankOwnedSharedProjectile);
 auto survivor=rec(5,2,"CTerrorPlayer");survivor.team=2;survivor.zombieClass=8;grenade.thrower=survivor.handle;f.records={tank,survivor,grenade};assert(identifyRock(grenade,f).kind==Identity::None);
 survivor.team=3;f.records={tank,survivor,grenade};assert(identifyRock(grenade,f).kind==Identity::TankOwnedSharedProjectile);
 survivor.serial=3;survivor.handle=(3<<12)|5;f.records={tank,survivor,grenade};assert(identifyRock(grenade,f).kind==Identity::None);
 grenade.thrower.reset();grenade.owner=0xffffffffu;f.records={tank,grenade};assert(identifyRock(grenade,f).kind==Identity::None);
 grenade.owner=tank.handle;grenade.className="CPhysicsProp";assert(identifyRock(grenade,f).kind==Identity::None);
 grenade.className="CBaseCSGrenadeProjectile";grenade.parent=0xffffffffu;grenade.networkOrigin=dango::Vec3{1,2,3};grenade.velocity=dango::Vec3{100,0,100};grenade.simulationTime=1.f;f.records={tank,grenade};
 Tracker tracker;Options o;o.predict=o.experimentalGravity=true;tracker.configure(o);tracker.discover(f);assert(tracker.tracks().size()==1);tracker.observe(grenade,100);assert(tracker.tracks().at(grenade.handle).identity==Identity::TankOwnedSharedProjectile);assert(!tracker.tracks().at(grenade.handle).trajectory.empty());assert(tracker.tracks().at(grenade.handle).confidence<=.25f);
 // Evidence at admission survives thrower removal; identity/class changes cannot attach new samples.
 grenade.owner.reset();grenade.simulationTime=1.02f;tracker.observe(grenade,120);assert(tracker.tracks().at(grenade.handle).history.size()==2);
 grenade.className="CPhysicsProp";tracker.observe(grenade,140);assert(tracker.tracks().at(grenade.handle).history.size()==2);
 tracker.reset(2);f.epoch=2;f.records={grenade};tracker.discover(f);assert(tracker.tracks().empty());
 std::cout<<"PASS: shared projectile inference, Tank actor identity, non-Tank rejection, serial reuse, thrower priority, no class-only grenade admission\n";
}
