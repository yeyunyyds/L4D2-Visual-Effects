#include "rock_landing.hpp"
#include "rock_settings.hpp"
#include <cassert>
#include <iostream>
using namespace visual::rocks;
int main(){
 Sample s;s.position={0,0,100};s.velocity={100,0,0};s.velocityValid=true;s.wallMs=100;
 auto floor=[](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;if(b.z<=0){r.fraction=a.z/(a.z-b.z);r.end=a+(b-a)*r.fraction;r.plane.normal={0,0,1};}return true;};
 unsigned budget=64;auto hit=predictLanding(s,320,100,budget,floor);assert(hit.valid());assert(std::abs(hit.seconds-std::sqrt(200.f/320))<.002f);assert(std::abs(hit.position.z)<.001f);assert(hit.rays<=60&&budget<64);
 auto disk=landingDisk(hit.position,hit.normal);for(auto p:disk){assert(std::abs(p.z-1)<.001f);assert(std::abs(dango::length(p-(hit.position+hit.normal))-32)<.001f);}
 auto nohit=[](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;return true;};budget=64;hit=predictLanding(s,320,100,budget,nohit);assert(hit.state==LandingState::NoHit&&hit.rays==60);
 budget=2;hit=predictLanding(s,320,100,budget,nohit);assert(hit.state==LandingState::BudgetExhausted&&hit.rays==2);
 budget=64;hit=predictLanding(s,320,100,budget,[](Vec3,Vec3,dango::trace::Result&){return false;});assert(hit.state==LandingState::Unavailable);
 budget=64;hit=predictLanding(s,320,100,budget,[](Vec3 a,Vec3,dango::trace::Result& r){r.start=a;r.startSolid=1;return true;});assert(hit.state==LandingState::StartSolid);
 budget=64;hit=predictLanding(s,320,100,budget,[](Vec3 a,Vec3 b,dango::trace::Result& r){r.start=a;r.end=b;r.fraction=-1;return true;});assert(hit.state==LandingState::Invalid);
 assert(nextExperimentalGravity(300)==320&&nextExperimentalGravity(320)==340&&nextExperimentalGravity(1200)==240);
 Options o;assert(o.gravity==320&&!o.experimentalGravity&&!o.mapCollision);
 DisplaySettings display;assert(display.landingCircle&&display.landingOpacity==.5f);nlohmann::json j;display.landingOpacity=.3f;display.landingCircle=false;writeDisplaySettings(j,display);auto read=readDisplaySettings(j);assert(!read.landingCircle&&read.landingOpacity==.3f);
 read=readDisplaySettings({{"tankRockDisplay",{{"landingOpacity",900},{"landingCircle","bad"}}}});assert(read.landingOpacity==.8f&&read.landingCircle);
 // Arrival-time velocity regression is marked as an estimate; difference velocities cannot calibrate it.
 Tracker t;o.sample=o.predict=o.calibrateGravity=true;t.configure(o);dango::inventory::Record r;r.className="CTankRock";r.index=3;r.serial=2;r.handle=(2<<12)|3;r.parent=0xffffffffu;
 dango::inventory::Frame f;f.epoch=1;f.tick=100;f.records={r};t.discover(f);
 for(int i=0;i<60;++i){float dt=i*.016f;r.networkOrigin=ballistic({0,0,200},{100,0,100},320,dt);r.velocity=Vec3{100,0,100-320*dt};t.observe(r,100+i*16);}
 const auto& tr=t.tracks().at(r.handle);assert(tr.gravityCalibrated&&!tr.gravitySimulationClock);assert(std::abs(tr.gravity-320)<.01f);assert(!tr.trajectory.empty());assert(tr.confidence<=.15f);
 t.reset(2);f.epoch=2;t.discover(f);r.velocity.reset();for(int i=0;i<60;++i){r.networkOrigin=Vec3{float(i),0,200};t.observe(r,100+i*16);}assert(!t.tracks().at(r.handle).gravityCalibrated);
 std::cout<<"PASS: world-ray impact, filled disk geometry, no-hit/failure/budget handling, 320 parameter, display migration, estimated gravity fit\n";
}
