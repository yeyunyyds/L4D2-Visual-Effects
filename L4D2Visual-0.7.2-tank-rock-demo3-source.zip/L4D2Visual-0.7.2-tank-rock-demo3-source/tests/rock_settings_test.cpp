#include "rock_settings.hpp"
#include "rock_tracker.hpp"
#include <cassert>
#include <iostream>
int main(){
 using namespace visual::rocks;
 nlohmann::json legacy={{"preset",2},{"spray",{{"enabled",true}}}};
 auto settings=readDisplaySettings(legacy);assert(settings.markers&&settings.direction&&settings.trajectory&&!settings.errors);assert(settings.opacity==.8f);
 Options options;assert(!options.anyEnabled()&&!options.experimentalGravity&&!options.calibrateGravity);
 settings.opacity=.4f;settings.color=2;settings.markers=false;settings.errors=true;writeDisplaySettings(legacy,settings);
 assert(legacy["preset"]==2);auto restored=readDisplaySettings(legacy);assert(restored.opacity==.4f&&restored.color==2&&!restored.markers&&restored.errors);
 assert(!legacy["tankRockDisplay"].contains("identify"));assert(!legacy["tankRockDisplay"].contains("experimentalGravity"));
 auto malformed=readDisplaySettings({{"tankRockDisplay",{{"opacity",-10},{"color",-1},{"markers","bad"},{"errors",42}}}});
 assert(malformed.opacity==.1f&&malformed.color==0&&malformed.markers&&!malformed.errors);
 assert(readDisplaySettings({{"tankRockDisplay",nullptr}}).opacity==.8f);
 std::cout<<"rock settings tests passed\n";
}
