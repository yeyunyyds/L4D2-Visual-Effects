#!/usr/bin/env python3
"""Analyze schema-1 rock JSONL; correlations are observational, never ping estimates."""
import argparse
import collections
import json
import math


def correlation(pairs):
    if len(pairs) < 3:
        return None
    xs, ys = zip(*pairs)
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    xx = sum((x - mx) ** 2 for x in xs)
    yy = sum((y - my) ** 2 for y in ys)
    return sum((x - mx) * (y - my) for x, y in pairs) / math.sqrt(xx * yy) if xx * yy > 0 else None


def analyze(lines):
    pending = collections.OrderedDict()
    groups = collections.defaultdict(list)
    unmatched = malformed = ambiguous = 0
    for line in lines:
        try:
            frame = json.loads(line)
            epoch = frame['epoch']
            rocks = {r['handle']: r for r in frame.get('rocks', [])}
            for event in frame.get('events', []):
                reason = event['reason']
                if reason != 'prediction' and not reason.startswith('error ('):
                    continue
                key = (epoch, event['handle'], event['target_state_time'], tuple(event['predicted']))
                if reason == 'prediction':
                    r = rocks.get(event['handle'], {})
                    metrics = r.get('metrics', {})
                    horizon = round((event['target_state_time'] - event['state_time']) * 1000)
                    context = {
                        'horizon': horizon,
                        'clock': event['clock_source'],
                        'speed': math.sqrt(sum(v * v for v in event['velocity'])),
                        'distance': r.get('distance_to_eye'),
                        'interval': metrics.get('simulation_interval_ms'),
                        'relative_delay': metrics.get('relative_delay_ms'),
                    }
                    if key in pending:
                        pending[key] = None
                        ambiguous += 1
                    else:
                        pending[key] = context
                    if len(pending) > 10000:
                        pending.popitem(last=False)
                else:
                    context = pending.pop(key, None)
                    if context is None:
                        unmatched += 1
                    else:
                        context['error'] = event['error']
                        groups[(context['clock'], context['horizon'])].append(context)
        except (ValueError, KeyError, TypeError):
            malformed += 1
    result = {'absolute_network_latency_available': False,
              'unmatched_error_events': unmatched, 'ambiguous_predictions': ambiguous,
              'malformed_lines': malformed, 'groups': []}
    for (clock, horizon), rows in sorted(groups.items()):
        errors = [r['error'] for r in rows]
        correlations = {}
        for field in ('speed', 'distance', 'interval', 'relative_delay'):
            pairs = [(r[field], r['error']) for r in rows if r.get(field) is not None
                     and math.isfinite(r[field]) and math.isfinite(r['error'])]
            correlations[field] = {'n': len(pairs), 'pearson_r': correlation(pairs)}
        result['groups'].append({'clock': clock, 'horizon_ms': horizon, 'count': len(rows),
                                 'mean': sum(errors) / len(errors),
                                 'rms': math.sqrt(sum(e * e for e in errors) / len(errors)),
                                 'max': max(errors), 'correlations': correlations})
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', nargs='+', help='logs in chronological order, previous before current')
    args = parser.parse_args()
    def lines():
        for path in args.log:
            with open(path, encoding='utf-8') as source:
                yield from source
    print(json.dumps(analyze(lines()), indent=2, ensure_ascii=False, allow_nan=False))
