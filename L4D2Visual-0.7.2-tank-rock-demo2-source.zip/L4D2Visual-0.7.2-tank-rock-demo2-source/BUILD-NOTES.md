Source base: dfb73d9. Matched experimental DLL SHA256: 2463dadd189c37598c32c728270c2b874c696515cc34b36329b304f33136c70e
Run bash scripts/test.sh; build using MinGW x86 via scripts/build-mingw.sh.
This environment used official Debian MinGW GCC12 and -Wno-error=array-bounds for seven preexisting vendored ImGui warnings. No game validation. See docs/experiments/tank-rock.md.
