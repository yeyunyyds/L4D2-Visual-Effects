#pragma once
#include "rock_runtime.hpp"
#include "rock_settings.hpp"
#include "imgui/imgui.h"
#include <sstream>
namespace visual::rockui {
using Settings=rocks::DisplaySettings;
inline std::shared_ptr<const Settings> settings=std::make_shared<const Settings>();
inline void readSettings(const nlohmann::json& j){std::atomic_store(&settings,std::make_shared<const Settings>(rocks::readDisplaySettings(j)));}
inline void writeSettings(nlohmann::json& j){rocks::writeDisplaySettings(j,*std::atomic_load(&settings));}
inline std::string row(const std::string& label,uintptr_t id=0){std::ostringstream o;o<<'"'<<label<<"\" { \"user_data\" \"0x"<<std::hex<<id<<"\" }\n";return o.str();}
inline std::string toggle(const char* label,bool enabled){return std::string(label)+(enabled?u8"：开":u8"：关");}
inline std::string menu(){auto o=std::atomic_load(&rockruntime::options);auto s=std::atomic_load(&settings);auto f=std::atomic_load(&rockruntime::snapshot);
 std::string states;if(f->discovery){states+=row(u8"全实体读取："+std::to_string(f->discovery->records)+u8"；未知类："+std::to_string(f->discovery->unknownClass));unsigned n=0;for(const auto& c:f->discovery->candidates){if(n++>=8)break;states+=row("projectile "+std::to_string(c.record.index)+":"+std::to_string(c.record.serial)+" "+c.identification.reason);}}unsigned stateRows=0;for(const auto& item:f->tracks){if(stateRows++>=8)break;states+=row(std::to_string(item.second.record.index)+":"+std::to_string(item.second.record.serial)+" "+std::string(rocks::identityName(item.second.identity))+" "+rocks::stateName(item.second.state));}
 return "\"Tank 石头实验 demo2\" {"+row(toggle(u8"A 实体识别",o->identify),750)+row(toggle(u8"B 高频运动采样",o->sample),751)+row(toggle(u8"C 轨迹预测与误差",o->predict),752)+
 row(u8"B/C 自动启用共享识别；脱手为推断状态")+row(toggle(u8"实验重力参数授权",o->experimentalGravity),753)+row(u8"实验重力："+std::to_string(int(o->gravity))+u8"（循环调整）",754)+row(toggle(u8"观测重力校准",o->calibrateGravity),755)+
 row(u8"轨迹长度："+std::to_string(int(o->horizon*1000))+" ms",756)+row(toggle(u8"位置与未来时间标记",s->markers),757)+row(toggle(u8"速度方向",s->direction),758)+row(toggle(u8"轨迹折线",s->trajectory),759)+row(toggle(u8"预测误差显示",s->errors),760)+row(u8"颜色："+std::to_string(s->color+1),761)+row(u8"不透明度："+std::to_string(int(s->opacity*100))+"%",762)+row(toggle(u8"后台诊断 JSONL",rockruntime::diagnostics.load()),763)+row(u8"重试实验模块",764)+row(u8"活跃石头："+std::to_string(f->tracks.size()))+row(rockruntime::status.load())+states+row(u8"理论轨迹；无碰撞截断，无延迟补偿")+row(u8"尚需真实游戏验证；开关不跨会话保存")+"}";
}
inline bool action(uintptr_t id){if(id<750||id>764)return false;auto o=*std::atomic_load(&rockruntime::options);auto s=*std::atomic_load(&settings);
 switch(id){case 750:o.identify=!o.identify;break;case 751:o.sample=!o.sample;break;case 752:o.predict=!o.predict;break;case 753:o.experimentalGravity=!o.experimentalGravity;break;case 754:o.gravity=o.gravity>=1200?400:o.gravity+100;break;case 755:o.calibrateGravity=!o.calibrateGravity;break;case 756:o.horizon=o.horizon>=1.f?.3f:o.horizon+.1f;break;case 757:s.markers=!s.markers;break;case 758:s.direction=!s.direction;break;case 759:s.trajectory=!s.trajectory;break;case 760:s.errors=!s.errors;break;case 761:s.color=(s.color+1)%3;break;case 762:s.opacity=s.opacity>=.99f?.2f:std::min(1.f,s.opacity+.1f);break;case 763:rockruntime::diagnostics=!rockruntime::diagnostics.load();break;case 764:rockruntime::faulted=false;break;default:break;}
 std::atomic_store(&settings,std::make_shared<const Settings>(s));std::atomic_store(&rockruntime::options,std::make_shared<const rocks::Options>(o));return true;
}
inline bool needed(){auto f=std::atomic_load(&rockruntime::snapshot);return !rockruntime::faulted.load()&&rockruntime::active()&&(!f->tracks.empty()||(f->discovery&&!f->discovery->candidates.empty()));}
inline bool project(const dango::GameCameraFrame& camera,dango::Vec3 p,float w,float h,ImVec2& result){dango::Vec3 ndc;if(!dango::transform(camera.worldToClip,p,ndc,true)||ndc.z<0||ndc.z>1||std::abs(ndc.x)>1.2f||std::abs(ndc.y)>1.2f)return false;result={(ndc.x+1)*w*.5f,(1-ndc.y)*h*.5f};return true;}
inline void draw(float width,float height){try{
 auto frame=std::atomic_load(&rockruntime::snapshot);auto camera=std::atomic_load(&source_camera::snapshot);auto s=std::atomic_load(&settings);auto options=std::atomic_load(&rockruntime::options);auto now=GetTickCount64();
 if(frame->epoch!=camera->epoch||!dango::usableCamera(*camera,now)||now<frame->tick||now-frame->tick>250)return;
 const ImVec4 colors[]={{.2f,1,.4f,s->opacity},{1,.65f,.15f,s->opacity},{.2f,.75f,1,s->opacity}};auto color=ImGui::ColorConvertFloat4ToU32(colors[std::min(s->color,2u)]);auto drawList=ImGui::GetBackgroundDrawList();
 if(frame->discovery&&frame->discovery->epoch==camera->epoch&&now>=frame->discovery->tick&&now-frame->discovery->tick<=500&&s->markers){for(const auto& c:frame->discovery->candidates){const auto& r=c.record;if(frame->tracks.count(r.handle)||!r.parent||*r.parent!=0xffffffffu||!r.networkOrigin||!rocks::valid(*r.networkOrigin))continue;ImVec2 at;if(project(*camera,*r.networkOrigin,width,height,at)){auto candidateColor=ImGui::ColorConvertFloat4ToU32({1,.65f,.15f,s->opacity});drawList->AddCircle(at,5,candidateColor,12,1);char text[256];std::snprintf(text,sizeof(text),"UNCONFIRMED projectile %u:%u\n%s",r.index,r.serial,c.identification.reason);drawList->AddText({at.x+8,at.y},candidateColor,text);}}}
 for(const auto& item:frame->tracks){const auto& t=item.second;const auto& r=t.record;
  if(!r.parent||*r.parent!=0xffffffffu||!r.networkOrigin||!rocks::valid(*r.networkOrigin)||t.state==rocks::State::Destroyed||t.state==rocks::State::Stale)continue;
  ImVec2 at;if(!project(*camera,*r.networkOrigin,width,height,at))continue;
  if(s->markers){drawList->AddCircle(at,6,color,12,2);char text[256];std::snprintf(text,sizeof(text),"rock %u:%u %s\nnet raw; %s; confidence heuristic %.0f%%",r.index,r.serial,rocks::stateName(t.state),t.history.empty()?"no sample":(t.history.back().simulationClock?"network clock":"wall-clock estimate"),t.confidence*100);drawList->AddText({at.x+9,at.y},color,text);}
  if(s->markers)drawList->AddText({at.x+9,at.y-16},color,rocks::identityName(t.identity));
  if(t.history.empty())continue;const auto& latest=t.history.back();if(now<latest.wallMs||now-latest.wallMs>250)continue;
  if((options->sample||options->predict)&&s->direction&&latest.velocityValid){ImVec2 tip;if(project(*camera,latest.position+latest.velocity*.1f,width,height,tip)){drawList->AddLine(at,tip,color,2);drawList->AddCircleFilled(tip,3,color);}}
  if(options->predict&&s->trajectory){ImVec2 previous;bool hasPrevious=false;for(const auto& p:t.trajectory){ImVec2 next;if(project(*camera,p.position,width,height,next)){if(hasPrevious)drawList->AddLine(previous,next,color,2);previous=next;hasPrevious=true;}else hasPrevious=false;}}
  if(options->predict&&s->markers&&t.gravityValid&&latest.velocityValid){for(float horizon:rocks::Horizons){if(horizon>options->horizon+.001f)continue;auto p=latest.position+latest.velocity*horizon+dango::Vec3{0,0,-t.gravity}*(.5f*horizon*horizon);ImVec2 next;if(!project(*camera,p,width,height,next))continue;drawList->AddCircle(next,4,color,10,1);char text[32];std::snprintf(text,sizeof(text),"%d ms",int(horizon*1000));drawList->AddText({next.x+5,next.y+5},color,text);}}
  if(s->errors){char text[480];std::snprintf(text,sizeof(text),"err RMS 50/100/200/300/500ms: %.1f %.1f %.1f %.1f %.1f\ncount: %llu %llu %llu %llu %llu\nupdates %llu repeats %llu invalid %llu; dt %.1fms\ntheory / no collision / no latency correction",t.errors[0].rms(),t.errors[1].rms(),t.errors[2].rms(),t.errors[3].rms(),t.errors[4].rms(),static_cast<unsigned long long>(t.errors[0].count),static_cast<unsigned long long>(t.errors[1].count),static_cast<unsigned long long>(t.errors[2].count),static_cast<unsigned long long>(t.errors[3].count),static_cast<unsigned long long>(t.errors[4].count),static_cast<unsigned long long>(t.metrics.updates),static_cast<unsigned long long>(t.metrics.repeats),static_cast<unsigned long long>(t.metrics.invalid),t.metrics.intervalMs);drawList->AddText({at.x+9,at.y+54},color,text);}
 }
}catch(...){rockruntime::faulted=true;rockruntime::status="Rock overlay disabled after exception";}
}
}
