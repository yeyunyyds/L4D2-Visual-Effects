# Tank 石头实验 A / B / C

> 当前 demo2 增加共享投射物 + Tank actor 推断和未确认候选诊断；原 demo1 实机未发现实体。差异、证据边界与再测步骤见 [demo2 排查报告](tank-rock-demo2.md)。下文构建哈希和首次验证记录属于 demo1。

## 交付边界

基于检出提交 `dfb73d9`（0.7.2）扩展，目标仍是 Windows x86 / L4N v2。实现三个独立开关及共享追踪核心，**没有真实游戏运行结果**。模拟测试和交叉编译只能验证算法、边界及构建，不能证明当前客户端实际暴露了所需字段。

该版本没有任务提及的 `tank_runtime.hpp`、`tank_sequence_catalog.hpp`、`tank_visual_state.hpp`，也没有 50 ms 战斗采样。实际调用链为已验证的 `VClient016::View_Render[25]` → `source_camera::capture` → 插件 `onFrame` → `source_entities::onFrame`。全实体清单每 200 ms 采集；原有单目标跟随为 33 ms。新增模块从清单发现石头后，在每次相机渲染回调中仅重读已知石头；未提高全实体扫描频率，未增加 D3D Hook。

## 游戏内使用

打开 L4N → L4D2Visual → **Tank 石头实验**。A / B / C、重力校准、实验重力授权和日志均默认关闭且不跨会话保存。B 或 C 自动使用共享识别基础，不要求手动开启 A；C 自动获取运动样本。

1. 开启 A 查看发现的类、身份和状态。只允许 `CTankRock` / `TankRock` 客户端类精确匹配；模型名仅用于诊断，不参与识别兜底。
2. 开启 B 查看位置、速度及质量。父 handle 必须明确为无效 handle `0xffffffff` 才允许将网络位置作为未挂接坐标使用；父字段缺失或仍挂接时拒绝轨迹。
3. 开启 C，并显式授权实验重力参数，或启用观测重力校准。未经授权的默认数值 800 不会用于预测。参数可在菜单调整；观测校准依赖连续可用的网络速度和模拟时间。
4. 可开启位置/未来时刻标记、速度方向、轨迹折线和误差显示；颜色、透明度可调，轨迹长度可调。保存设置只保存外观，不保存实验开关。
5. 需要诊断时打开后台 JSONL；复现后关闭。模块异常只禁用石头路径，可关闭全部实验后重启。原有兼容性与 VAC 风险声明继续适用，无 VAC 安全认证。

## 模块与只读接口

| 文件 | 职责 |
| --- | --- |
| `src/rock_tracker.hpp` | 无 Windows 依赖的生命周期、样本、质量、轨迹与误差核心 |
| `src/rock_runtime.hpp` | 已验证实体读取适配、原子只读快照、后台诊断 |
| `src/rock_settings.hpp` | 外观持久化与旧配置兼容 |
| `src/rock_ui.hpp` | 独立菜单及现有 ImGui HUD 投影 |

未来调用方通过 `std::atomic_load(&visual::rockruntime::snapshot)` 获取不可变快照，并检查 epoch、wall tick、新样本年龄和状态。`tracks` 按完整 handle（包含 serial）索引；`Track::record` 提供 index、serial、客户端类和模型，`history.back()` 提供当前有效运动状态，`trajectory` 提供未来 seconds、position、velocity，`errors[0..4]` 对应 50/100/200/300/500 ms。`gravityValid`、`gravityCalibrated`、`Sample::source`、`Sample::simulationClock`、metrics、confidence 一起表达质量；confidence 仅为保守启发式分数，**不是经过统计校准的命中概率**。快照还提供可用时的相机眼睛位置，方便计算空间关系；不包含武器或攻击指令逻辑。

## A：生命周期

状态包括 discovered、held、unknown parent、release inferred、flight inferred、stopped inferred、destroyed/identity unavailable、stale。父实体存在是挂接观测，不保证一定挂在 Tank 的手上；脱手、飞行和停止由未挂接及运动阈值推断，不宣称引擎直接标记。低于 20 units/s 视为停止候选，并非碰撞确认。没有可信速度时不伪造“停止”。

每次定向读取使用既有 raw entity list、类型化 RecvTable 字段、受限 ReadProcessMemory 及 tiny getter 解码。先验证 handle / serial，读后再次验证 entity 地址及 serial。新身份不会承接旧轨迹。地图 epoch、断开、全部关闭清空状态；身份明确失效终止轨迹；暂时读取失败与销毁区分。没有新样本超过 250 ms 时停止显示预测；超过 500 ms 未见实体进入 stale，超过 2 秒回收。最多 64 条追踪记录。

Tank 死亡没有专门删除全部石头：已经飞出的石头应继续按自身实体身份追踪；手持实体销毁/父关系变化由实体读取反映。无法确认 Tank 死亡后客户端是否立即销毁手持石头，需实测，不能按 owner 死亡误删真实飞行实体。

## B：时间与数据质量

优先使用无父实体的 `m_vecOrigin`，不调用未经验证的 abs-origin 虚函数，不读取猜测的 `m_vecAbsOrigin` 偏移。样本是网络字段观测，**不是客户端插值后的渲染位置**。

新增 RecvTable 白名单仅允许 `m_vecVelocity[0]` / `m_vecVelocity` 的 DPT_Vector 和 `m_flSimulationTime` 的 DPT_Float，按真实字段类型读取。Source 某些构建的 simulation time 使用 DPT_Int + RecvProxy 写入 float，或速度仅提供浮点分量；这些布局当前故意拒绝，不能把整型属性无条件解释成 float。尚未验证相关 proxy 指纹，因此可能无法获得直接速度、直接模拟时间。

有可靠模拟时间时，仅时间推进构成新网络样本；逐帧重复值单独计数，同一模拟时间位置变化记异常。速度缺失使用位置差分，标记 Difference。模拟时间缺失时退化为**位置变化到达时间估计**，标记 `simulationClock=false`，不会宣称测得服务器 tickrate；抖动和插值可能显著影响该估计，置信度上限更低。时间域切换清空运动历史，避免串联。

每实体最多 128 个历史样本、512 个待回填预测。metrics 记录读取数、新状态、重复、异常、读取失败、超过 50 ms 的间隔、采样间隔与相对到达漂移。相对漂移不是 ping、单程网络延迟，也不等于客户端插值延迟；没有获取服务器时钟同步或可靠网络延迟字段。“丢帧/丢失”只能用模拟时间间隔异常、读取失败率和日志队列丢弃数衡量，不能据此断言服务器真实丢包率。

## C：模型与误差

使用 `P(t)=P0+V0*t+(0,0,-g)*t²/2`，每 25 ms 分段生成最多 1 秒轨迹。固定未来跨度 50、100、200、300、500 ms 进入待验证队列。取得后续观测后，用跨越目标时间的两次位置作线性插值，累计 count、mean、RMS、max；跨越大于 75 ms 的缺口不生成虚构真值。日志标明插值观测，实际测量仍包含网络/观测误差；回弹或碰撞会造成误差，不能解释为纯重力偏差。

重力来源只有显式实验参数或观测校准：至少四个连续有效网络速度差分，水平加速度较小且垂直加速度范围合理才允许校准。持有、未知父实体、时间跳变和模型选项变化清空拟合，避免跨飞行混用。没有引入不透明的固定补偿，也未调用新 CVar/物理接口。该模型可能忽略石头旋转、引擎自定义重力倍率、空气阻力或特殊地图行为。

**本次轨迹均为理论轨迹。** 未实现网络插值/绝对延迟补偿；未实现地图碰撞截断。现有喷漆 Trace 为表面放置用途，不能据此将石头中心射线称为真实 projectile hull 碰撞预测。地图、玩家、移动物体碰撞均需后续独立验证。

## 诊断与分析

日志路径为 DLL 配置目录 `L4D2Visual/tank-rock.jsonl`，超过 16 MiB 轮换为 `tank-rock.previous.jsonl`。64 帧有界队列，采样线程 try_lock；无法入队记录 dropped_log_frames。所有 JSON 格式化和文件写入在既有后台 worker，游戏/Present 线程没有频繁文件 I/O。关闭日志停止入队与写入；诊断生成也可关闭。

schema 1 每帧包含 epoch / wall_ms、坐标与轨迹模型标签、rocks 与 events。实体包含完整身份、父关系、状态与发现/销毁时间、原始字段、质量计数、重力来源、各跨度误差；事件包含样本时间域、位置速度和来源、预测目标/位置、后续插值位置及 error 或拒绝原因。分析时按 epoch + handle 分组，按误差事件关联速度、间隔、相对漂移以及眼睛到石头距离，分别比较各时间跨度。可检验这些因素与误差的关系，**当前没有真实日志，因此没有可报告的真实相关系数或误差数值**。

## 验证与剩余工作

自动化覆盖创建、挂接/释放推断、销毁、index 复用、多石头、地图切换、过期、缺失速度/时间、重复时间/异常坐标、匀速/重力、误差回填、30/60/100 tick、到达抖动/漏样、选项切换及旧配置。字段假 Reader 测试覆盖 RecvTable allowlist、基类偏移、类型、坏表和地址边界；原有回归套件继续运行。实际命令与结果见本报告后续验证记录。

实机下一步需采集：客户端真实 class name / 字段类型、parent 释放语义、坐标是否已经世界空间、网络速度与重力、不同 FPS/tick 的更新节奏和误差。200 ms 发现周期会延迟首次发现，寿命短于扫描间隔的石头可能完全遗漏；逐帧定向读取不能解决发现延迟。若实测不可接受，需要另行验证实体创建通知接口。

后续刀石功能还需：玩家眼睛与移动预测、近战判定体积/扫掠路径、各武器攻击延迟和动画/服务器判定时间、延迟与插值估计、地图碰撞、误差分布和建议时间区间。应从只读快照计算入近战范围时间，并结合实测武器延迟给建议；本次不发送攻击、不修改服务器状态、不实现自动挥刀。

离线分析命令：`python3 scripts/analyze-rock-log.py tank-rock.previous.jsonl tank-rock.jsonl > rock-analysis.json`（日志按时间顺序传入，可只传一个文件）。工具将预测与回填按 epoch、handle、目标时间和预测位置关联，分别输出时间域/跨度的误差与速度、距离、采样间隔、相对漂移的 Pearson 相关系数；常量或样本不足返回 null。队列丢弃造成无法关联的误差单独计数。相对漂移相关性不能解释为 ping 相关性；输出不是因果分析。Python 测试验证关联、RMS、相关系数和缺失事件处理。

### 本次构建记录

在 Linux 环境以官方 Debian MinGW GCC 12 交叉编译，调用现有 `scripts/build-mingw.sh`；输出 PE32 DLL / Intel i386，4,756,508 字节，构建退出码 0。

SHA256：`07aaa7b73d33892d75dce4b4b482dd99e05a1283caab643688354854bf5df50a`。

该编译器对未改动的 vendored ImGui 在 `-O2 -Werror` 下产生 7 条既有 array-bounds 诊断；独立编译确认同样失败。本次使用本地编译器包装器添加 `-Wno-error=array-bounds` 完成验证，其他警告仍作为错误，石头项目代码没有编译诊断。未修改构建脚本或 ImGui 来掩盖警告；原始严格命令在该 GCC 12 工具链上仍会因既有诊断失败。交付包含构建日志和基线证据。

### 自动化结果

`bash scripts/test.sh` 退出码 0：18 个 C++ 测试程序（含三个新增石头套件和字体套件）全部通过 ASan / UBSan；3 项 Python 日志分析测试通过。菜单字形扩展后另以 `-O0` + ASan / UBSan 复核字体测试通过；其余 C++ 主套件采用脚本中的 `-Werror -pedantic`。`git diff --check` 通过。详细输出保存于 `docs/experiments/tank-rock-validation.txt`。

30 / 60 / 100 tick 的理想弹道模拟中，五档插值观测误差均通过 RMS < 0.2 units 的断言；零重力匀速模拟通过 RMS < 0.001 units 的断言。这些仅是人工数据的算法验证阈值，不是真实石头精度。日志分析对相同目标时刻/位置的重复预测作歧义计数并跳过，避免误归类时间跨度；丢失或跨日志缺失的预测同样不补造数据。
