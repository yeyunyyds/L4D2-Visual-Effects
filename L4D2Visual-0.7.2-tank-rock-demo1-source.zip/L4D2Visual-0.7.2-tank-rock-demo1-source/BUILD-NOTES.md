Source base: dfb73d9. Matched experimental DLL SHA256: 07aaa7b73d33892d75dce4b4b482dd99e05a1283caab643688354854bf5df50a
Run bash scripts/test.sh; build using MinGW x86 via scripts/build-mingw.sh.
This environment used official Debian MinGW GCC12 and -Wno-error=array-bounds for seven preexisting vendored ImGui warnings. No game validation. See docs/experiments/tank-rock.md.
