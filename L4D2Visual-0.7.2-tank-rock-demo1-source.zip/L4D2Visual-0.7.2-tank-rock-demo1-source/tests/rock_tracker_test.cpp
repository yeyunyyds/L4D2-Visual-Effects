#include "rock_tracker.hpp"
#include <cassert>
#include <iostream>
using namespace visual::rocks;
using dango::inventory::Record;
Record rock(unsigned index=7,unsigned serial=2){Record r;r.index=index;r.serial=serial;r.handle=(serial<<12)|index;r.className="CTankRock";r.parent=0xffffffffu;r.simulationTime=0;r.networkOrigin=Vec3{100,200,300};r.velocity=Vec3{100,20,200};return r;}
void discover(Tracker& t,const Record& r,uint64_t ms=100){dango::inventory::Frame f;f.epoch=1;f.tick=ms;f.records={r};t.discover(f);}
Options options(){Options o;o.identify=o.sample=o.predict=o.experimentalGravity=true;return o;}
Record at(Record r,float time,float gravity=800){r.simulationTime=time;r.networkOrigin=Vec3{100+100*time,200+20*time,300+200*time-.5f*gravity*time*time};r.velocity=Vec3{100,20,200-gravity*time};return r;}
int main(){
 Tracker t;auto r=rock();discover(t,r);assert(t.tracks().empty());t.configure(options());discover(t,r);assert(t.tracks().size()==1);
 r.parent=42;t.observe(r,100);assert(t.tracks().at(r.handle).state==State::Held);assert(t.tracks().at(r.handle).history.empty());r.parent.reset();t.observe(r,110);assert(t.tracks().at(r.handle).state==State::UnknownParent);r.parent=0xffffffffu;t.observe(r,120);assert(t.tracks().at(r.handle).history.size()==1);
 t.observe(r,125);assert(t.tracks().at(r.handle).metrics.repeats==1);r.networkOrigin=Vec3{std::numeric_limits<float>::quiet_NaN(),0,0};t.observe(r,130);assert(t.tracks().at(r.handle).metrics.invalid==1);
 r=at(rock(),.02f);r.velocity.reset();t.observe(r,140);assert(t.tracks().at(r.handle).history.back().source==VelocitySource::Difference);
 auto r2=rock(8);discover(t,r2);t.observe(r2,140);assert(t.tracks().size()==2);auto replacement=rock(7,3);discover(t,replacement,150);assert(t.tracks().at(rock().handle).state==State::Destroyed);t.observe(replacement,150);assert(t.tracks().at(replacement.handle).history.size()==1);t.missing(replacement.handle,155);assert(t.tracks().at(replacement.handle).trajectory.empty());t.expire(3000);assert(t.tracks().empty());
 for(int tick:{30,60,100}){
  Tracker sim;auto o=options();sim.configure(o);auto base=rock();discover(sim,base);for(int i=0;i<100;++i){float time=float(i)/tick;auto obs=at(base,time);uint64_t arrival=100+uint64_t(time*1000)+unsigned(i%3)*2;sim.observe(obs,arrival);sim.observe(obs,arrival+1);}
  const auto& tr=sim.tracks().at(base.handle);assert(tr.history.size()<=128);assert(tr.metrics.repeats==100);for(auto& e:tr.errors){assert(e.count>0);assert(e.rms()<.2);}assert(tr.trajectory.size()>1);
 }
 {Tracker sim;auto o=options();o.gravity=0;sim.configure(o);discover(sim,rock());for(int i=0;i<90;++i)sim.observe(at(rock(),i*.01f,0),100+i*10);for(auto& e:sim.tracks().at(rock().handle).errors)assert(e.rms()<.001);}
 {Tracker sim;auto o=options();o.experimentalGravity=false;o.calibrateGravity=true;sim.configure(o);discover(sim,rock());for(int i=0;i<80;++i){if(i%7==3)continue;sim.observe(at(rock(),i/60.f),150+i*17+(i%3));}auto& tr=sim.tracks().at(rock().handle);assert(tr.gravityCalibrated);assert(std::abs(tr.gravity-800)<.01);assert(tr.metrics.updates<80);assert(tr.pending.size()<=512);}
 {Tracker sim;auto o=options();o.experimentalGravity=false;sim.configure(o);discover(sim,rock());sim.observe(rock(),100);assert(sim.tracks().begin()->second.trajectory.empty());sim.expire(700);assert(sim.tracks().begin()->second.state==State::Stale);dango::inventory::Frame f;f.epoch=2;f.tick=710;sim.discover(f);assert(sim.tracks().empty());}
 {Tracker sim;sim.configure(options());for(unsigned i=0;i<100;++i)discover(sim,rock(i));assert(sim.tracks().size()==64);sim.configure({});assert(sim.tracks().empty());}
 {Tracker sim;sim.configure(options());discover(sim,rock());sim.observe(rock(),100);sim.observe(rock(),400);assert(sim.tracks().begin()->second.state==State::Stale);assert(sim.tracks().begin()->second.trajectory.empty());sim.observe(at(rock(),.02f),420);assert(sim.tracks().begin()->second.state==State::FlyingInferred);}
 {Tracker sim;sim.configure(options());auto obs=rock();obs.simulationTime.reset();discover(sim,obs);sim.observe(obs,100);for(int i=1;i<80;++i){auto next=at(rock(),i*.01f);next.simulationTime.reset();sim.observe(next,100+i*10+(i%3));}const auto& tr=sim.tracks().begin()->second;assert(!tr.history.back().simulationClock);assert(tr.confidence<=.15f);assert(tr.metrics.updates==80);assert(!tr.trajectory.empty());auto o=options();o.gravity=600;sim.configure(o);assert(sim.tracks().begin()->second.history.empty());}
 {Tracker sim;Options o;o.identify=true;sim.configure(o);auto obs=rock();discover(sim,obs);obs.parent=42;sim.observe(obs,100);obs.parent=0xffffffffu;sim.observe(obs,110);assert(sim.tracks().begin()->second.state==State::ReleasedInferred);assert(sim.tracks().begin()->second.history.empty());}
 {Tracker sim;sim.configure(options());auto obs=rock();obs.simulationTime.reset();const uint64_t uptime=10000000000ull;discover(sim,obs,uptime);sim.observe(obs,uptime);auto next=at(rock(),.01f);next.simulationTime.reset();sim.observe(next,uptime+10);const auto& tr=sim.tracks().begin()->second;assert(tr.history.size()==2);assert(std::abs(tr.history.back().simulationTime-.01f)<.00001f);assert(!tr.gravityCalibrated);}
 {Tracker sim;auto o=options();sim.configure(o);discover(sim,rock());sim.observe(rock(),100);assert(sim.takeEvents().empty());o.diagnostics=true;sim.configure(o);for(int i=1;i<80;++i)sim.observe(at(rock(),i*.01f),100+i*10);auto events=sim.takeEvents();assert(!events.empty());bool errors=false;for(const auto& e:events)if(e.reason.find("error (")==0)errors=true;assert(errors);o.diagnostics=false;sim.configure(o);assert(sim.takeEvents().empty());}
 std::cout<<"rock tracker lifecycle, sampling, predictions: passed\n";
}
