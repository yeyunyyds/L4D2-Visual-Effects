#include "source_entity_contract.hpp"
#include <array>
#include <iostream>
#include <stdexcept>
using namespace dango;
void check(bool value){if(!value)throw std::runtime_error("rock schema regression");}
struct Reader {
 std::array<unsigned char,8192> bytes{};size_t reads=0;
 bool read(uint32_t address,void* out,size_t count){++reads;if(address<0x1000||uint64_t(address-0x1000)+count>bytes.size())return false;std::memcpy(out,bytes.data()+address-0x1000,count);return true;}
 template<class T> void put(uint32_t address,const T& value){check(address>=0x1000&&uint64_t(address-0x1000)+sizeof(T)<=bytes.size());std::memcpy(bytes.data()+address-0x1000,&value,sizeof(T));}
 void text(uint32_t address,const char* value){check(uint64_t(address-0x1000)+std::strlen(value)+1<=bytes.size());std::memcpy(bytes.data()+address-0x1000,value,std::strlen(value)+1);}
};
int main(){
 Reader r;entitywire::Table derived{},base{};derived.props=0x1200;derived.count=2;derived.name=0x1600;base.props=0x1400;base.count=2;base.name=0x1640;
 r.text(derived.name,"DT_TankRock");r.text(base.name,"DT_BaseEntity");
 entitywire::Prop inheritance{},velocity{},time{},origin{};
 inheritance.name=0x1680;inheritance.type=6;inheritance.table=0x1100;inheritance.offset=16;r.text(inheritance.name,"baseclass");
 velocity.name=0x1700;velocity.type=2;velocity.offset=96;r.text(velocity.name,"m_vecVelocity[0]");
 time.name=0x1740;time.type=1;time.offset=80;r.text(time.name,"m_flSimulationTime");
 origin.name=0x1780;origin.type=2;origin.offset=100;r.text(origin.name,"m_vecOrigin");
 r.put(0x1000,derived);r.put(0x1100,base);r.put(derived.props,inheritance);r.put(derived.props+sizeof(inheritance),velocity);r.put(base.props,time);r.put(base.props+sizeof(time),origin);
 entitywire::Fields fields;check(entitywire::fields(r,0x1000,fields));check(fields.size()==3);check(fields.at("m_vecVelocity[0]").offset==96&&fields.at("m_vecVelocity[0]").type==2);check(fields.at("m_flSimulationTime").offset==96&&fields.at("m_flSimulationTime").type==1);check(fields.at("m_vecOrigin").offset==116);
 // A vector alias is preserved; producer must still check the advertised type.
 r.text(velocity.name,"m_vecVelocity");velocity.type=1;r.put(derived.props+sizeof(inheritance),velocity);check(entitywire::fields(r,0x1000,fields));check(fields.at("m_vecVelocity").type==1);
 // Fail closed for bad types/offsets, corrupt table bounds, and recursive bases.
 velocity.type=8;r.put(derived.props+sizeof(inheritance),velocity);check(!entitywire::fields(r,0x1000,fields));velocity.type=2;velocity.offset=-1;r.put(derived.props+sizeof(inheritance),velocity);check(!entitywire::fields(r,0x1000,fields));velocity.offset=65537;r.put(derived.props+sizeof(inheritance),velocity);check(!entitywire::fields(r,0x1000,fields));velocity.offset=96;r.put(derived.props+sizeof(inheritance),velocity);
 base.count=2049;r.put(0x1100,base);check(!entitywire::fields(r,0x1000,fields));base.count=2;base.props=0xfffffff0;r.put(0x1100,base);check(!entitywire::fields(r,0x1000,fields));base.props=0x1400;r.put(0x1100,base);
 inheritance.table=0x1000;r.put(derived.props,inheritance);size_t before=r.reads;check(!entitywire::fields(r,0x1000,fields));check(r.reads-before<100);
 check(!entitywire::handle(4096,0));check(!entitywire::handle(1,0x100000));check(!entitywire::handle(4095,0xfffff));auto a=entitywire::handle(42,3),b=entitywire::handle(42,4);check(a&&b&&a!=b&&(*a&4095)==42&&(*b>>12)==4);
 std::cout<<"PASS: rock network schema allowlist, inherited offsets, types, malformed tables, bounded recursion and handle reuse\n";
}
