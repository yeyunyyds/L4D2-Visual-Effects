#pragma once
#include "dango/entity_inventory.hpp"
#include <deque>
#include <array>
#include <limits>
#include <utility>
namespace visual::rocks {
using dango::Vec3;
inline constexpr std::array<float,5> Horizons{.05f,.1f,.2f,.3f,.5f};
inline bool valid(Vec3 p,float limit=32768){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z)&&std::max({std::abs(p.x),std::abs(p.y),std::abs(p.z)})<=limit;}
inline bool rockClass(const std::string& s){return s=="CTankRock"||s=="TankRock";}
enum class State {Discovered,Held,UnknownParent,ReleasedInferred,FlyingInferred,StoppedInferred,Destroyed,Stale};
inline const char* stateName(State s){switch(s){case State::Discovered:return "discovered";case State::Held:return "held (parent observed)";case State::UnknownParent:return "unknown parent / no world coordinate";case State::ReleasedInferred:return "release inferred";case State::FlyingInferred:return "flight inferred";case State::StoppedInferred:return "stopped inferred";case State::Destroyed:return "destroyed / identity unavailable";case State::Stale:return "stale";}return "unknown";}
enum class VelocitySource {Unavailable,Network,Difference};
struct Options {
 bool identify=false,sample=false,predict=false,experimentalGravity=false,calibrateGravity=false,diagnostics=false;
 float gravity=800,horizon=.5f;
 bool anyEnabled()const{return identify||sample||predict;}
};
struct Sample {uint64_t wallMs=0;float simulationTime=0;Vec3 position{},velocity{};bool velocityValid=false,simulationClock=true;VelocitySource source=VelocitySource::Unavailable;};
struct Point {float seconds=0;Vec3 position{},velocity{};};
struct ErrorStats {uint64_t count=0;double sum=0,sumSquared=0,max=0,speedSum=0,intervalSum=0,arrivalAgeSum=0;double mean()const{return count?sum/count:0;}double rms()const{return count?std::sqrt(sumSquared/count):0;}};
struct Metrics {uint64_t reads=0,updates=0,repeats=0,invalid=0,readFailures=0,gaps=0;double intervalMs=0,arrivalMs=0,relativeDelayMs=0;};
struct Pending {float baseTime=0,targetTime=0,horizon=0;Vec3 position{};float speed=0,interval=0,arrivalAge=0;};
struct Track {
 dango::inventory::Record record;State state=State::Discovered;uint64_t createdMs=0,lastSeenMs=0,destroyedMs=0;
 std::deque<Sample> history;std::deque<Pending> pending;std::vector<Point> trajectory;std::array<ErrorStats,5> errors{};Metrics metrics;
 float gravity=0;bool gravityValid=false,gravityCalibrated=false;unsigned gravityFits=0;double gravitySum=0;float confidence=0;uint64_t lastReadMs=0,baselineWallMs=0;float baselineTime=0;bool baselineValid=false;
};
struct Event {uint64_t wallMs=0;uint32_t handle=0;std::string reason;Sample sample{};float targetTime=0;Vec3 predicted{},actual{};float error=0;};
class Tracker {
 Options options_;uint32_t epoch_=0;std::map<uint32_t,Track> tracks_;std::deque<Event> events_;
 void event(uint64_t ms,uint32_t handle,const std::string& reason,const Sample& s={}){if(!options_.diagnostics)return;if(events_.size()==2048)events_.pop_front();events_.push_back({ms,handle,reason,s,0,{},{},0});}
 void clearMotion(Track& t){t.history.clear();t.pending.clear();t.trajectory.clear();t.gravityFits=0;t.gravitySum=0;t.gravityCalibrated=t.gravityValid=false;t.baselineValid=false;t.confidence=0;}
 void transition(Track& t,State s,uint64_t ms){if(t.state!=s){t.state=s;event(ms,t.record.handle,stateName(s));}}
 void predictions(Track& t,const Sample& s){
  t.trajectory.clear();if(!options_.predict||!s.velocityValid||!t.gravityValid)return;
  const Vec3 g{0,0,-t.gravity};float horizon=std::clamp(options_.horizon,.05f,1.f);
  for(unsigned i=0;i<=unsigned(std::ceil(horizon/.025f));++i){float dt=std::min(i*.025f,horizon);t.trajectory.push_back({dt,s.position+s.velocity*dt+g*(.5f*dt*dt),s.velocity+g*dt});}
  for(float h:Horizons){if(t.pending.size()==512)t.pending.pop_front();auto p=s.position+s.velocity*h+g*(.5f*h*h);t.pending.push_back({s.simulationTime,s.simulationTime+h,h,p,dango::length(s.velocity),float(t.metrics.intervalMs),float(t.metrics.relativeDelayMs)});if(options_.diagnostics){Event e{s.wallMs,t.record.handle,"prediction",s,s.simulationTime+h,p,{},0};if(events_.size()==2048)events_.pop_front();events_.push_back(e);}}
 }
 void backfill(Track& t,const Sample& previous,const Sample& current){
  while(!t.pending.empty()&&t.pending.front().targetTime<previous.simulationTime-1e-5f)t.pending.pop_front();
  for(auto it=t.pending.begin();it!=t.pending.end();){
   if(it->targetTime>current.simulationTime+1e-5f){++it;continue;}
   if(it->targetTime<previous.simulationTime-1e-5f){it=t.pending.erase(it);continue;}
   float dt=current.simulationTime-previous.simulationTime;
   // Never invent ground truth across missing snapshots or a large discontinuity.
   if(dt>0&&dt<=.075f){float alpha=std::clamp((it->targetTime-previous.simulationTime)/dt,0.f,1.f);Vec3 actual=previous.position+(current.position-previous.position)*alpha;float error=dango::length(actual-it->position);auto index=std::find(Horizons.begin(),Horizons.end(),it->horizon)-Horizons.begin();auto& stats=t.errors[size_t(index)];++stats.count;stats.sum+=error;stats.sumSquared+=error*error;stats.max=std::max(stats.max,double(error));stats.speedSum+=it->speed;stats.intervalSum+=it->interval;stats.arrivalAgeSum+=it->arrivalAge;if(options_.diagnostics){Event e{current.wallMs,t.record.handle,current.simulationClock?"error (simulation-time interpolated observation)":"error (wall-time interpolated estimate)",current,it->targetTime,it->position,actual,error};if(events_.size()==2048)events_.pop_front();events_.push_back(e);}}
   it=t.pending.erase(it);
  }
 }
public:
 void configure(Options o){if(!o.diagnostics)events_.clear();o.gravity=std::isfinite(o.gravity)?std::clamp(o.gravity,0.f,4000.f):800;o.horizon=std::isfinite(o.horizon)?std::clamp(o.horizon,.05f,1.f):.5f;if(options_.anyEnabled()&&!o.anyEnabled()){tracks_.clear();events_.clear();}if(options_.sample!=o.sample||options_.predict!=o.predict||options_.gravity!=o.gravity||options_.experimentalGravity!=o.experimentalGravity||options_.calibrateGravity!=o.calibrateGravity)for(auto& item:tracks_)clearMotion(item.second);options_=o;}
 const Options& options()const{return options_;}
 void reset(uint32_t epoch){tracks_.clear();events_.clear();epoch_=epoch;}
 const std::map<uint32_t,Track>& tracks()const{return tracks_;}
 std::vector<Event> takeEvents(){std::vector<Event> out(events_.begin(),events_.end());events_.clear();return out;}
 void discover(const dango::inventory::Frame& f){
  if(!options_.anyEnabled())return;
  if(f.epoch!=epoch_)reset(f.epoch);
  for(const auto& r:f.records){if(!rockClass(r.className)||r.index>=2048||r.serial!=(r.handle>>12)||(r.handle&4095)!=r.index)continue;
   for(auto& item:tracks_)if(item.first!=r.handle&&item.second.record.index==r.index&&item.second.state!=State::Destroyed)missing(item.first,f.tick);
   if(tracks_.count(r.handle))continue;
   if(tracks_.size()>=64){auto old=std::find_if(tracks_.begin(),tracks_.end(),[](const auto& x){return x.second.state==State::Destroyed||x.second.state==State::Stale;});if(old==tracks_.end())continue;tracks_.erase(old);}
   Track t;t.record=r;t.createdMs=t.lastSeenMs=f.tick;tracks_.emplace(r.handle,std::move(t));event(f.tick,r.handle,"created");
  }
 }
 void missing(uint32_t handle,uint64_t ms){auto it=tracks_.find(handle);if(it==tracks_.end())return;auto& t=it->second;transition(t,State::Destroyed,ms);t.destroyedMs=ms;t.confidence=0;t.pending.clear();t.trajectory.clear();}
 void expire(uint64_t ms){for(auto it=tracks_.begin();it!=tracks_.end();){auto& t=it->second;if(ms>=t.lastSeenMs&&ms-t.lastSeenMs>500&&t.state!=State::Destroyed){transition(t,State::Stale,ms);t.confidence=0;t.pending.clear();t.trajectory.clear();}if(ms>=t.lastSeenMs&&ms-t.lastSeenMs>2000)it=tracks_.erase(it);else ++it;}}
 void observe(const dango::inventory::Record& r,uint64_t ms){
  if(!options_.anyEnabled())return;
  auto it=tracks_.find(r.handle);if(it==tracks_.end()||r.serial!=it->second.record.serial||r.index!=it->second.record.index||!rockClass(r.className))return;auto& t=it->second;
  if(t.state==State::Destroyed)return;
  t.record=r;t.lastSeenMs=ms;++t.metrics.reads;if(t.lastReadMs&&ms>=t.lastReadMs)t.metrics.arrivalMs=double(ms-t.lastReadMs);t.lastReadMs=ms;
  if(!r.parent){transition(t,State::UnknownParent,ms);clearMotion(t);return;}
  if(*r.parent!=0xffffffffu){transition(t,State::Held,ms);clearMotion(t);return;}
  if(!options_.sample&&!options_.predict){
   if(r.networkOrigin&&valid(*r.networkOrigin)&&r.velocity&&valid(*r.velocity,20000)){
    bool moving=dango::length(*r.velocity)>20;
    transition(t,moving?(t.state==State::Held||t.state==State::Discovered?State::ReleasedInferred:State::FlyingInferred):State::StoppedInferred,ms);
   }
   return;
  }
  if(!r.networkOrigin||!valid(*r.networkOrigin)||(r.simulationTime&&(!std::isfinite(*r.simulationTime)||*r.simulationTime<0))||(r.dormant&&*r.dormant)){++t.metrics.invalid;t.confidence=0;event(ms,r.handle,"invalid origin / simulation time / dormant");t.trajectory.clear();return;}
  Sample s;s.wallMs=ms;s.position=*r.networkOrigin;s.simulationClock=bool(r.simulationTime);s.simulationTime=r.simulationTime?*r.simulationTime:float((double(ms)-double(t.createdMs))/1000);
  if(!t.history.empty()&&s.simulationClock!=t.history.back().simulationClock)clearMotion(t);
  if(!t.history.empty()){
   const Sample prev=t.history.back();float dt=s.simulationTime-prev.simulationTime;
   if(dt==0||(!s.simulationClock&&dango::length(s.position-prev.position)<.001f)){++t.metrics.repeats;if(s.simulationClock&&dango::length(s.position-prev.position)>.01f){++t.metrics.invalid;t.confidence=0;t.pending.clear();t.trajectory.clear();event(ms,r.handle,"position changed with duplicate simulation clock");}if(ms>=prev.wallMs&&ms-prev.wallMs>250){transition(t,State::Stale,ms);t.confidence=0;t.pending.clear();t.trajectory.clear();}return;}
   if(dt<0||dt>1||dango::length(s.position-prev.position)>20000*dt+64){++t.metrics.invalid;clearMotion(t);event(ms,r.handle,"simulation time reset / discontinuity");return;}
   t.metrics.intervalMs=dt*1000;if(dt>.05f)++t.metrics.gaps;
   t.metrics.relativeDelayMs=(double(ms)-double(t.baselineWallMs))-double(s.simulationTime-t.baselineTime)*1000;
   if(r.velocity&&valid(*r.velocity,20000)){s.velocity=*r.velocity;s.velocityValid=true;s.source=VelocitySource::Network;}
   else{s.velocity=(s.position-prev.position)*(1/dt);s.velocityValid=valid(s.velocity,20000);s.source=VelocitySource::Difference;}
   if(options_.calibrateGravity&&s.simulationClock&&prev.simulationClock&&s.source==VelocitySource::Network&&prev.source==VelocitySource::Network&&dt<=.1f){Vec3 a=(s.velocity-prev.velocity)*(1/dt);if(std::abs(a.x)<100&&std::abs(a.y)<100&&a.z<=0&&a.z>=-4000){t.gravitySum+=-a.z;++t.gravityFits;if(t.gravityFits>=4){t.gravity=float(t.gravitySum/t.gravityFits);t.gravityValid=t.gravityCalibrated=true;}}}
   backfill(t,prev,s);
  }else if(r.velocity&&valid(*r.velocity,20000)){s.velocity=*r.velocity;s.velocityValid=true;s.source=VelocitySource::Network;}
  if(!t.gravityCalibrated){t.gravity=options_.gravity;t.gravityValid=options_.experimentalGravity;}
  bool moving=s.velocityValid&&dango::length(s.velocity)>20;
  State next=moving?(t.state==State::Held||t.state==State::Discovered?State::ReleasedInferred:State::FlyingInferred):(s.velocityValid?State::StoppedInferred:State::Discovered);
  if(!t.baselineValid){t.baselineValid=true;t.baselineWallMs=ms;t.baselineTime=s.simulationTime;}
  transition(t,next,ms);if(t.history.size()==128)t.history.pop_front();t.history.push_back(s);++t.metrics.updates;t.confidence=t.gravityValid&&s.velocityValid?(s.simulationClock?(t.gravityCalibrated?.7f:.3f):.15f):0;
  if(moving)predictions(t,s);else{t.pending.clear();t.trajectory.clear();}
  event(ms,r.handle,s.simulationClock?"sample network simulation clock":"sample wall-clock estimate (no simulation time)",s);
 }
 void readFailure(uint32_t handle,uint64_t ms){auto it=tracks_.find(handle);if(it!=tracks_.end()){++it->second.metrics.readFailures;it->second.confidence=0;it->second.pending.clear();it->second.trajectory.clear();event(ms,handle,"read failure");}}
};
}
