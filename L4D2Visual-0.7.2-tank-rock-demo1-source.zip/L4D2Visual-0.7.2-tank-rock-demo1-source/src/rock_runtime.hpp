#pragma once
#include "dango/source_entities.hpp"
#include "rock_tracker.hpp"
#include <deque>
#include <mutex>
namespace visual::rockruntime {
inline std::shared_ptr<const rocks::Options> options=std::make_shared<const rocks::Options>();
inline std::atomic<bool> diagnostics{false},faulted{false};
inline std::atomic<const char*> status{"Tank rock experiments off"};
struct Snapshot {uint32_t epoch=0;uint64_t tick=0;std::map<uint32_t,rocks::Track> tracks;uint64_t droppedLogs=0;std::vector<rocks::Event> events;std::optional<dango::Vec3> viewerEye;};
inline std::shared_ptr<const Snapshot> snapshot=std::make_shared<const Snapshot>();
inline rocks::Tracker tracker;
inline bool active(){return std::atomic_load(&options)->anyEnabled();}
// One immutable frame is shared by rendering and the bounded diagnostic queue.
// JSON formatting and all file operations run exclusively in drain().
inline std::mutex logMutex;
inline std::deque<std::shared_ptr<const Snapshot>> logQueue;
inline uint64_t droppedLogs=0;
inline std::shared_ptr<const source_entities::Frame> inventory;
inline uint32_t epoch=0;inline bool running=false;
inline std::optional<source_entities::Record> directed(uint32_t handle,const dango::GameCameraFrame& camera,bool& identityGone){
 using namespace source_entities;
 if(!bound||source_entities::faulted||!list)return {};
 unsigned index=handle&4095u;if(index>=source_entities::profile::MaxNetworked)return {};
 uint32_t object=uint32_t(reinterpret_cast<uintptr_t>(list));
 auto entries=uint32_t(int64_t(object)+source_entities::profile::EntryBaseDelta);
 wire::Entry entry{};uint32_t net=0;
 if(!wire::load(reader,entries+index*sizeof(entry),entry))return {};
 if(!entry.entity||entry.serial!=(handle>>12)){identityGone=true;return {};}
 if(!wire::load(reader,object+source_entities::profile::CacheOffset+index*8,net)||!net)return {};
 Frame frame;frame.epoch=camera.epoch;frame.tick=camera.tick;
 auto record=readRecord(index,entry,net,frame);
 // Revalidate after the read: reject entity reuse during a sample.
 wire::Entry after{};
 if(!record||!wire::load(reader,entries+index*sizeof(after),after)||after.entity!=entry.entity||after.serial!=entry.serial)return {};
 return record;
}
inline void onFrame(const dango::GameCameraFrame& camera)noexcept{
 try{
 auto settings=std::atomic_load(&options);
 if(!settings->anyEnabled()||!camera.active){
  if(running){if(diagnostics){auto reset=std::make_shared<Snapshot>();reset->epoch=camera.epoch;reset->tick=camera.tick;rocks::Event e;e.wallMs=camera.tick;e.reason="camera inactive / experiments off: tracker reset";reset->events.push_back(e);std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock()){if(logQueue.size()>=64)logQueue.pop_front();logQueue.push_back(reset);}}tracker.reset(camera.epoch);std::atomic_store(&snapshot,std::make_shared<const Snapshot>());inventory.reset();}
  running=false;faulted=false;status="Tank rock experiments off / camera inactive";return;
 }
 if(faulted)return;
 bool changedEpoch=running&&epoch!=camera.epoch;
 if(!running||epoch!=camera.epoch){tracker.reset(camera.epoch);inventory.reset();epoch=camera.epoch;running=true;}
 auto effective=*settings;effective.diagnostics=diagnostics.load();tracker.configure(effective);
 auto latest=std::atomic_load(&source_entities::snapshot);
 if(latest!=inventory){inventory=latest;if(latest->epoch==camera.epoch&&camera.tick>=latest->tick&&camera.tick-latest->tick<=500)tracker.discover(*latest);}
 std::vector<uint32_t> handles;for(const auto& item:tracker.tracks()){if(item.second.state==rocks::State::Destroyed)continue;if(handles.size()>=64)break;handles.push_back(item.first);}
 for(auto handle:handles){bool gone=false;auto record=directed(handle,camera,gone);if(record)tracker.observe(*record,camera.tick);else if(gone)tracker.missing(handle,camera.tick);else tracker.readFailure(handle,camera.tick);}
 tracker.expire(camera.tick);
 auto frame=std::make_shared<Snapshot>();frame->epoch=camera.epoch;frame->tick=camera.tick;frame->tracks=tracker.tracks();frame->droppedLogs=droppedLogs;auto events=tracker.takeEvents();if(diagnostics)frame->events=std::move(events);dango::CameraPose pose;if(dango::cameraPose(camera,pose))frame->viewerEye=pose.eye;if(changedEpoch&&diagnostics){rocks::Event e;e.wallMs=camera.tick;e.reason="map epoch changed: previous tracker state cleared";frame->events.push_back(e);}
 std::shared_ptr<const Snapshot> published=frame;std::atomic_store(&snapshot,published);
 if(diagnostics){std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock()){if(logQueue.size()>=64){logQueue.pop_front();++droppedLogs;}logQueue.push_back(published);}else ++droppedLogs;}
 else {std::unique_lock<std::mutex> lock(logMutex,std::try_to_lock);if(lock.owns_lock())logQueue.clear();}
 status="Rock class discovery + frame-directed reads; game validation pending";
 }catch(...){faulted=true;status="Rock module disabled after exception; toggle experiments off to reset";std::atomic_store(&snapshot,std::make_shared<const Snapshot>());}
}
inline void drain(const std::filesystem::path& directory){
 std::deque<std::shared_ptr<const Snapshot>> frames;
 {std::lock_guard<std::mutex> lock(logMutex);frames.swap(logQueue);}
 if(!diagnostics||frames.empty())return;
 try{
 std::filesystem::create_directories(directory);
 auto path=directory/L"tank-rock.jsonl";
 if(std::filesystem::exists(path)&&std::filesystem::file_size(path)>16*1024*1024){auto previous=directory/L"tank-rock.previous.jsonl";std::filesystem::remove(previous);std::filesystem::rename(path,previous);}
 std::ofstream file(path,std::ios::binary|std::ios::app);
 for(const auto& frame:frames){
  nlohmann::json out={{"schema",1},{"epoch",frame->epoch},{"wall_ms",frame->tick},{"dropped_log_frames",frame->droppedLogs},{"space","network_origin_unparented_only"},{"trajectory_kind","theoretical_no_collision_no_latency_compensation"},{"rocks",nlohmann::json::array()}};
  if(frame->viewerEye)out["viewer_eye"]={frame->viewerEye->x,frame->viewerEye->y,frame->viewerEye->z};
  out["absolute_network_latency_known"]=false;
  for(const auto& item:frame->tracks){const auto& track=item.second;auto r=track.record;
   nlohmann::json value={{"handle",r.handle},{"serial",r.serial},{"index",r.index},{"class",r.className},{"model",r.modelName},{"state",int(track.state)},{"state_name",rocks::stateName(track.state)}};
   if(r.networkOrigin)value["network_origin"]={r.networkOrigin->x,r.networkOrigin->y,r.networkOrigin->z};
   if(r.velocity)value["network_velocity"]={r.velocity->x,r.velocity->y,r.velocity->z};
   if(r.simulationTime)value["simulation_time"]=*r.simulationTime;
   if(r.parent)value["parent"]=*r.parent;
   if(frame->viewerEye&&!track.history.empty())value["distance_to_eye"]=dango::length(track.history.back().position-*frame->viewerEye);
   value["created_ms"]=track.createdMs;value["last_seen_ms"]=track.lastSeenMs;value["destroyed_ms"]=track.destroyedMs;
   value["metrics"]={{"reads",track.metrics.reads},{"updates",track.metrics.updates},{"repeats",track.metrics.repeats},{"invalid",track.metrics.invalid},{"read_failures",track.metrics.readFailures},{"gaps_over_50ms",track.metrics.gaps},{"simulation_interval_ms",track.metrics.intervalMs},{"arrival_interval_ms",track.metrics.arrivalMs},{"relative_delay_ms",track.metrics.relativeDelayMs}};
   value["gravity"]={{"value",track.gravity},{"valid",track.gravityValid},{"calibrated",track.gravityCalibrated},{"fits",track.gravityFits}};
   value["confidence_heuristic"]=track.confidence;value["error_stats"]=nlohmann::json::array();
   for(size_t i=0;i<track.errors.size();++i){const auto& e=track.errors[i];value["error_stats"].push_back({{"horizon_s",rocks::Horizons[i]},{"count",e.count},{"mean",e.mean()},{"rms",e.rms()},{"max",e.max},{"speed_sum",e.speedSum},{"interval_sum",e.intervalSum},{"arrival_age_sum",e.arrivalAgeSum}});}
   out["rocks"].push_back(std::move(value));
  }
  out["events"]=nlohmann::json::array();
  for(const auto& e:frame->events)out["events"].push_back({{"wall_ms",e.wallMs},{"handle",e.handle},{"reason",e.reason},{"state_time",e.sample.simulationTime},{"clock_source",e.sample.simulationClock?"network_simulation":"wall_clock_fallback"},{"position",{e.sample.position.x,e.sample.position.y,e.sample.position.z}},{"velocity",{e.sample.velocity.x,e.sample.velocity.y,e.sample.velocity.z}},{"velocity_source",int(e.sample.source)},{"velocity_valid",e.sample.velocityValid},{"target_state_time",e.targetTime},{"predicted",{e.predicted.x,e.predicted.y,e.predicted.z}},{"actual_interpolated",{e.actual.x,e.actual.y,e.actual.z}},{"error",e.error}});
  file<<out.dump(-1,' ',false,nlohmann::json::error_handler_t::replace)<<'\n';
 }
 if(!file)throw std::runtime_error("rock diagnostic write failed");
 }catch(...){diagnostics=false;status="Rock diagnostic output failed; logging disabled";}
}
}
