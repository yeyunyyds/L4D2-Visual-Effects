#pragma once
#include <array>
#include <cstdint>
namespace visual {
inline constexpr std::array<unsigned,5> AnimationPeriods{{8000,4000,2000,1000,500}};
inline unsigned validPeriod(unsigned period){for(auto value:AnimationPeriods)if(value==period)return value;return 2000;}
inline unsigned nextPeriod(unsigned period){for(unsigned i=0;i<AnimationPeriods.size();++i)if(AnimationPeriods[i]==period)return AnimationPeriods[(i+1)%AnimationPeriods.size()];return 2000;}
inline const char* speedLabel(unsigned period){switch(period){case 8000:return "0.25x / 8s";case 4000:return "0.5x / 4s";case 1000:return "2x / 1s";case 500:return "4x / 0.5s";default:return "1x / 2s";}}
}
