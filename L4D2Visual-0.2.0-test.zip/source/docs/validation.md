# 0.2.0-test 验证记录

已执行：

- 两个 Linux 测试程序在 ASan/UBSan 下通过：周期、范围、单调性、输入不变、
  身份/模型/地图/过期拒绝、矩阵变形、studio 数据边界、损坏层级拒绝、
  不同高度双脚及其脚趾在完整周期中保持原矩阵。
- Windows x86 GCC 14 POSIX 编译，-Wall -Wextra -Werror。
- 三个上传 DLL 的完整 SHA-256、PE 标识、接口工厂、构造器虚表、方法槽位和
  指令样本离线核对通过。未执行游戏 DLL。
- PE32 i386 输出及 GetL4NPluginInstance 导出检查。

未执行：Windows 加载、真实 L4N 菜单、游戏视觉、实际碰撞/命中对比、性能、
阴影、LOD、裁剪、与其他模型绘制插件共存。当前为待实机验证测试版。
