#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mutex>
#include <sstream>
#include "l4n/l4n_plugin.h"
#include "dango/source_entities.hpp"
#include "render_contract.hpp"
#include "source_render.hpp"

static_assert(sizeof(void*) == 4, "L4N requires Windows x86");
namespace {
std::atomic<bool> requested{false};
void note(const std::string& text) { OutputDebugStringA(("L4D2Visual: " + text + "\n").c_str()); }
const char* __cdecl toggle(void*) {
    bool value=!requested.load(); requested=value;
    source_entities::browseRequested=value;
    visual::render::startedAt=GetTickCount64();
    visual::render::enabled=value;
    return nullptr;
}
std::string menuText;
std::mutex menuMutex;
class Plugin final : public IL4NPlugin {
    void connect() {
        source_camera::logger=note;
        source_camera::frameListener=source_entities::onFrame;
        if(!source_camera::clientModule)source_camera::clientModule=GetModuleHandleW(L"client.dll");
        if(!source_camera::engineModule)source_camera::engineModule=GetModuleHandleW(L"engine.dll");
        source_camera::connect();
        visual::render::connect();
    }
public:
    const char* GetName() override {return "L4D2Visual";}
    const char* GetVersion() override {return "0.2.0-test";}
    void OnModuleLoaded(const char* name,std::uintptr_t handle) override {
        if(!name)return;
        std::string n(name);
        if(n=="client"||n=="client.dll")source_camera::clientModule=reinterpret_cast<HMODULE>(handle);
        if(n=="engine"||n=="engine.dll")source_camera::engineModule=reinterpret_cast<HMODULE>(handle);
        connect();
    }
    void OnGameLaunch() override {connect();}
    const char* RequestHudMenu(bool title) override {
        if(title)return "L4D2Visual 0.2.0-test";
        std::lock_guard<std::mutex> lock(menuMutex);
        auto frame=std::atomic_load(&source_entities::snapshot);
        unsigned count=0;
        for(const auto& r:frame->records)
            if(visual::specialInfected(r.className,r.team.value_or(-1)) &&
               r.dormant.has_value() && !*r.dormant)++count;
        std::ostringstream text;
        text << "\"L4D2Visual\" {\n\"" << (requested?u8"关闭拉伸测试":u8"开启拉伸测试")
             << "\" { \"callback\" \"0x" << std::hex
             << reinterpret_cast<std::uintptr_t>(&toggle) << "\" }\n";
        text << std::dec << "\"" << u8"特殊感染者快照数量：" << count << "\" {}\n";
        text << "\"" << u8"动画目标：0.5 - 1.5，往复 2 秒" << "\" {}\n";
        text << "\"" << visual::render::status.load() << "\" {}\n";
        text << "\"" << u8"已拉伸绘制次数：" << visual::render::drawn.load() << "\" {}\n";
        text << "\"" << u8"实体关联次数：" << visual::render::identified.load() << "\" {}\n";
        text << "\"" << u8"引擎/Studio 回调：" << visual::render::engineCalls.load() << "/" << visual::render::studioCalls.load() << "\" {}\n";
        text << "\"" << u8"姿态拒绝次数：" << visual::render::rejected.load() << "\" {}\n}";
        menuText=text.str();return menuText.c_str();
    }
    void stop() {requested=false;visual::render::stop();source_entities::browseRequested=false;source_camera::frameListener=nullptr;source_camera::stop();}
    ~Plugin() override {stop();}
};
Plugin& instance(){static Plugin object;return object;}
}
#if defined(__GNUC__) && !defined(_MSC_VER)
// Explicit nine-slot MSVC x86 adapter, matching the reference plugin.
namespace {
void* __fastcall destroy(void* self,void*,unsigned){instance().stop();return self;}
unsigned __fastcall version(void*,void*){return 2;}
const char* __fastcall name(void*,void*){return instance().GetName();}
const char* __fastcall release(void*,void*){return instance().GetVersion();}
void __fastcall module(void*,void*,const char* n,std::uintptr_t h){instance().OnModuleLoaded(n,h);}
void __fastcall launch(void*,void*){instance().OnGameLaunch();}
void __fastcall d3d(void*,void*,void*){}
void __fastcall device(void*,void*,void*,bool){}
const char* __fastcall menu(void*,void*,bool title){return instance().RequestHudMenu(title);}
void* table[]={reinterpret_cast<void*>(&destroy),reinterpret_cast<void*>(&version),reinterpret_cast<void*>(&name),reinterpret_cast<void*>(&release),reinterpret_cast<void*>(&module),reinterpret_cast<void*>(&launch),reinterpret_cast<void*>(&d3d),reinterpret_cast<void*>(&device),reinterpret_cast<void*>(&menu)};
struct Object{void** vtable;} object{table};
}
extern "C" __declspec(dllexport) IL4NPlugin* GetL4NPluginInstance(){return reinterpret_cast<IL4NPlugin*>(&object);}
#else
extern "C" __declspec(dllexport) IL4NPlugin* GetL4NPluginInstance(){return &instance();}
#endif
