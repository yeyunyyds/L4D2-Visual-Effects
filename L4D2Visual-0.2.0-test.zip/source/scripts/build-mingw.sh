#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
compiler="${CXX_X86:-i686-w64-mingw32-g++}"
if ! command -v "$compiler" >/dev/null && [[ -x /workspace/tools/mingw/usr/bin/i686-w64-mingw32-g++-posix ]]; then
  compiler=/workspace/tools/mingw/usr/bin/i686-w64-mingw32-g++-posix
fi
"$compiler" -std=c++17 -O2 -Wall -Wextra -Werror -Wno-unused-parameter -Wno-misleading-indentation -Wno-cast-function-type -shared -static -Isrc -Ivendor src/plugin.cpp src/L4D2Visual.def -o build/L4D2Visual.dll -luser32
