# L4D2Visual 0.2.0-test

Windows x86 / L4N v2 特殊感染者纯视觉拉伸测试插件。
已接入上传游戏构建的实体、引擎模型绘制和 Studio 绘制接口。
当前完成离线 ABI 校验、Linux 回归与 x86 交叉编译，尚未实机验收。

## 安装与测试

1. 完整退出游戏，将安装包的 `bin` 合并到游戏目录。
2. 保证 `bin/neko/plugins/L4D2Visual.dll` 只加载一份；不要运行时卸载。
3. 进图，在 L4N → **L4D2Visual 0.2.0-test** → **开启拉伸测试**。
4. 观察 Tank 及其他特殊感染者。默认关闭，开关不跨游戏会话保存。
5. 每次重新打开菜单刷新计数：实体关联、已拉伸绘制、引擎/Studio 回调。
6. 关闭测试，检查外观是否恢复；切图、目标死亡或离开视野后检查是否正常。

完整往复周期 **2000ms**：`0.5 → 1.5 → 0.5`，采用余弦平滑曲线。
0/500/1000/1500/2000ms 分别为 0.5/1/1.5/1/0.5 倍。
所有目标共用开启时的时间基准，X/Y 保持原值。

## 双脚和真实碰撞

从本次绘制的 studio 模型骨骼名称识别双脚，读取实际渲染骨骼，
对独立矩阵副本做 Z 缩放，再恢复脚部及其后代（包含脚趾）的完整原始矩阵。
因此双脚处于不同高度时也保留各自原始位置和朝向；原走路动画照常进行。
脚部与腿部的蒙皮过渡效果需实机确认，这不是额外的 IK 求解。

不写实体位置、模型缩放字段、碰撞边界、命中骨骼缓存或共享渲染骨骼。
仅 Studio DrawModel 收到变形副本，原引擎 DrawModelExecute 仍收到原始参数。
队列路径已静态确认会在函数返回前复制非渲染内存池的骨骼数据。
游戏侧真实碰撞/命中结果仍需与关闭测试时做实机对比。

## 目标与兼容性

沿用 DangoMusic 实体实验分支的特殊感染者分类：Smoker、Boomer、Hunter、
Spitter、Jockey、Charger、Tank、Witch，以及感染者队伍的
CTerrorPlayer / NextBotCombatCharacter。不额外按模型路径筛选类别；
模型名比对仅用于确认绘制参数确实对应识别到的实体。

使用地图代次、完整句柄、当前模型索引、休眠状态和快照时间检查目标。
未知骨骼、无法确认双脚、模型查询不可用、过期或构建不符时沿用原始绘制。
接口上已有未知模型绘制钩子时拒绝安装，不替换它。

## 当前限制

- 仅支持 `docs/research/render-profile.json` 中上传的三个游戏 DLL 构建。
- 已接入 DrawModelExecute → Studio DrawModel 常规模型路径。
  独立阴影路径、批量模型路径可能保持原样；不承诺所有 pass 都有拉伸。
- 不扩大真实碰撞箱，也未改变游戏渲染裁剪边界；1.5 倍时边缘裁剪、
  LOD、阴影一致性和非均匀缩放的光照仍需检查。
- 模型没有两根可识别 foot 骨骼时跳过。皮肤/模型替换的脚部权重可能不同。
- 尚未在 Windows/L4D2 中运行，不把交叉编译通过当成实机通过。

无效果时先等待一秒再重新打开菜单，记录全部计数和接口状态。
“关联次数为 0”与“关联成功但绘制为 0”表示不同阶段的问题。
初始化诊断也发送至 Windows OutputDebugString，可用 DebugView 收集。

## 开发与验证

```sh
ASAN_OPTIONS=detect_leaks=0 bash scripts/test.sh
bash scripts/build-mingw.sh
python3 scripts/package.py
python3 scripts/verify_render_profile.py --client /path/client.dll --engine /path/engine.dll --studio /path/studiorender.dll
```

测试使用 ASan/UBSan；当前运行器限制使泄漏检测不可用，单独关闭它。
交叉编译需要 i686-w64-mingw32-g++（可用 CXX_X86 指定）。
安装包含 DLL 与对应源码，不包含游戏 DLL。代码来源见 NOTICE.md。
离线证据与验证边界见 docs/validation.md、docs/research/render-abi.md。
