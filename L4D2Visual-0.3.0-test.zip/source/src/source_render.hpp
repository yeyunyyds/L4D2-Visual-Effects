#pragma once
#include <windows.h>
#include <atomic>
#include "dango/source_entities.hpp"
#include "render_contract.hpp"
#include "studio_pose.hpp"
#include "render_profile.hpp"

namespace visual::render {
using dango::Vec3;
struct DrawState {std::uint32_t header,hardware,renderable,modelToWorld,decals,flags,lod;};
struct ModelInfo {
    Vec3 origin,angles;
    std::uint32_t renderable,model,modelToWorld,lightingOffset,lightingOrigin;
    int flags,index,skin,body,hitbox;
    std::uint16_t instance,padding;
};
static_assert(sizeof(DrawState)==28 && offsetof(ModelInfo,index)==48 && sizeof(ModelInfo)==68);
using EngineDraw=void(__thiscall*)(void*,const DrawState&,const ModelInfo&,Matrix3x4*);
using StudioDraw=void(__thiscall*)(void*,void*,const void*,Matrix3x4*,float*,float*,const Vec3&,int);
inline EngineDraw engineOriginal=nullptr;
inline StudioDraw studioOriginal=nullptr;
inline void** engineTable=nullptr;
inline void** studioTable=nullptr;
inline std::atomic<bool> enabled{false},bound{false};
inline std::atomic<ULONGLONG> startedAt{0};
inline std::atomic<unsigned long> drawn{0},rejected{0};
inline std::atomic<unsigned long> engineCalls{0},identified{0},studioCalls{0};
inline std::atomic<const char*> identifyReason{"No target draw yet"},poseReason{"No associated studio draw yet"};
inline std::atomic<const char*> status{"Waiting for game modules"};
inline HMODULE studioModule=nullptr;
struct Context {bool valid=false;DrawIdentity identity{};std::uint32_t header{},renderable{};std::uint64_t age{};std::string model;};
inline thread_local Context* context=nullptr;

template<std::size_t N> bool samples(HMODULE module,const profile::Sample(&list)[N]) {
    for(const auto& sample:list) {
        const auto p=reinterpret_cast<const unsigned char*>(module)+sample.rva;
        if(!source_camera::readable(p,sample.length)){source_camera::log("Render fingerprint unreadable RVA="+std::to_string(sample.rva));return false;}
        for(unsigned i=0;i<sample.length;++i)
            if((p[i]&static_cast<unsigned char>(sample.mask[i]))!=
               (static_cast<unsigned char>(sample.bytes[i])&static_cast<unsigned char>(sample.mask[i]))){source_camera::log("Render fingerprint mismatch RVA="+std::to_string(sample.rva)+" byte="+std::to_string(i));return false;}
    }
    return true;
}
inline bool patch(void** table,unsigned slot,void* expected,void* replacement) {
    DWORD previous{};
    if(!VirtualProtect(table+slot,sizeof(void*),PAGE_READWRITE,&previous))return false;
    auto actual=InterlockedCompareExchangePointer(table+slot,replacement,expected);
    DWORD ignored{};VirtualProtect(table+slot,sizeof(void*),previous,&ignored);
    return actual==expected;
}
inline Context identify(const DrawState& state,const ModelInfo& info) {
    using namespace source_entities;
    Context result;
    if(info.index<0 || info.index>=int(source_entities::profile::MaxNetworked) ||
       !state.header || !state.renderable || state.renderable!=info.renderable){identifyReason="invalid index/header/renderable";return result;}
    const auto camera=std::atomic_load(&source_camera::snapshot);
    const auto frame=std::atomic_load(&snapshot);
    const auto now=GetTickCount64();
    if(!camera->active || camera->epoch!=frame->epoch || now<frame->tick ||
       now-frame->tick>250){identifyReason="inactive camera / map epoch / stale snapshot";return result;}
    const auto object=std::uint32_t(reinterpret_cast<std::uintptr_t>(source_camera::clientModule))+source_entities::profile::Object;
    wire::Entry entry;std::uint32_t net{};
    const auto entries=std::uint32_t(std::int64_t(object)+source_entities::profile::EntryBaseDelta);
    if(!wire::load(reader,entries+info.index*sizeof(entry),entry)||!entry.entity||
       !wire::load(reader,object+source_entities::profile::CacheOffset+info.index*8,net)||!net){identifyReason="entity entry or networkable unreadable";return result;}
    const auto handle=wire::handle(info.index,entry.serial);
    if(!handle){identifyReason="invalid handle";return result;}
    const dango::inventory::Record* record=nullptr;
    for(const auto& r:frame->records)if(r.handle==*handle){record=&r;break;}
    if(!record || !record->modelIndex || record->modelName.empty() ||
       !specialInfected(record->className,record->team.value_or(-1))){identifyReason="snapshot lacks special infected / model identity";return result;}
    // Decode the profiled tiny getters; do not execute entity virtual methods.
    std::uint32_t getter{};
    if(!method(state.renderable,0,getter)){identifyReason="renderable getter unavailable";return result;}
    auto base=wire::addressGetter(reader,getter,state.renderable);
    if(!base || *base!=entry.entity){identifyReason="renderable getter does not map to entity base";return result;}
    if(!method(net,source_entities::profile::DormantSlot,getter)){identifyReason="dormancy getter unavailable";return result;}
    auto dormant=wire::byteGetter(reader,getter,net);
    if(!dormant || *dormant){identifyReason="dormant or unknown dormancy";return result;}
    auto address=classAddress(net);if(!address){identifyReason="class getter unavailable";return result;}
    auto cls=readClass(*address);
    if(cls.name!=record->className){identifyReason="current class mismatch";return result;}
    auto team=field<int>(entry.entity,cls,"m_iTeamNum",0);
    if(!specialInfected(cls.name,team.value_or(-1))){identifyReason="current team is not special infected";return result;}
    const auto model=field<std::int16_t>(entry.entity,cls,"m_nModelIndex",0);
    if(!model || *model!=*record->modelIndex){identifyReason="current model index mismatch";return result;}
    identifyReason="Entity matched";result.valid=true;result.identity={frame->epoch,*handle,*model};
    result.header=state.header;result.renderable=state.renderable;
    result.age=now-frame->tick;result.model=record->modelName;
    return result;
}
inline void __fastcall engineHook(void* self,void*,const DrawState& state,const ModelInfo& info,Matrix3x4* bones) {
    ++engineCalls;
    Context current;
    if(enabled.load())try{current=identify(state,info);}catch(...){++rejected;}
    if(current.valid)++identified;
    struct Scope {Context* previous;~Scope(){context=previous;}} scope{context};
    context=&current;
    // Keep the original engine pose intact, including hitbox/debug consumers.
    engineOriginal(self,state,info,bones);
}
inline void __fastcall studioHook(void* self,void*,void* results,const void* info,Matrix3x4* bones,
                                  float* flex,float* delayed,const Vec3& origin,int flags) {
    ++studioCalls;
    PoseCopy source,copy;StudioPose studio;bool changed=false;
    try {
        std::uint32_t header{},renderable{};
        auto ptr=std::uint32_t(reinterpret_cast<std::uintptr_t>(info));
        if(enabled.load() && (context && context->valid) && (poseReason="Missing draw bone pointer",bones) &&
           source_entities::wire::load(source_entities::reader,ptr,header) &&
           source_entities::wire::load(source_entities::reader,ptr+24,renderable) &&
           (poseReason="Studio header/renderable context mismatch",header==context->header && renderable==context->renderable) &&
           (poseReason="Studio header / bone names / hierarchy rejected", studioPose(source_entities::reader,header,studio)) &&
           (poseReason="Studio model name differs from entity model",canonicalModel(studio.name)==canonicalModel(context->model)) &&
           (poseReason="Bone matrix memory unreadable",source_entities::reader.read(std::uint32_t(reinterpret_cast<std::uintptr_t>(bones)),
                                       source.bones.data(),studio.count*sizeof(Matrix3x4)))) {
            poseReason="Foot anchor invalid";float anchor{};
            if(footAnchor(studio,source.bones.data(),anchor)) {
                const auto elapsed=GetTickCount64()-startedAt.load();
                RenderInput input{context->identity,context->identity,source.bones.data(),studio.count,
                                  anchor,elapsed,context->age,true,true,false,true,true};
                poseReason="Nonfinite bone matrix / draw contract rejected";changed=prepareDraw(input,copy);
                if(changed)poseReason="Pose accepted";
                if(changed)preserveFeet(studio,source.bones.data(),copy);
            }
            if(!changed)++rejected;
        }
    }catch(...){++rejected;}
    // The verified studio implementation copies non-render-arena matrices for
    // queued draws (66e50). Our local copy survives until that copy completes.
    studioOriginal(self,results,info,changed?copy.bones.data():bones,flex,delayed,origin,flags);
    if(changed) {
        if(drawn.fetch_add(1)==0)source_camera::log("First visual stretch submitted; original entity and bone cache untouched");
        status="Stretch draws submitted; inspect feet and animation in game";
    }
}
inline void connect() {
    using namespace source_camera;
    if(bound.load())return;
    auto engineModule=source_camera::engineModule;
    auto clientModule=source_camera::clientModule;
    if(!studioModule)studioModule=GetModuleHandleW(L"studiorender.dll");
    if(!engineModule || !clientModule || !studioModule){status="Waiting for client/engine/studiorender modules";return;}
    status="Render ABI check failed; original drawing retained";
    if(!matchesImage(engineModule,EngineTimestamp,EngineImageSize,"visual engine") ||
       !matchesImage(clientModule,ClientTimestamp,ClientImageSize,"visual client") ||
       !matchesImage(studioModule,1782844886,6631424,"visual studio") ||
       !samples(engineModule,visual::profile::engineSamples) ||
       !samples(clientModule,visual::profile::clientSamples) ||
       !samples(studioModule,visual::profile::studioSamples))return;
    using Factory=void*(__cdecl*)(const char*,int*);
    auto ef=reinterpret_cast<Factory>(GetProcAddress(engineModule,"CreateInterface"));
    auto sf=reinterpret_cast<Factory>(GetProcAddress(studioModule,"CreateInterface"));
    if(!ef || !sf){status="CreateInterface export missing";return;}
    auto e=ef("VEngineModel016",nullptr),s=sf("VStudioRender026",nullptr);
    auto eb=reinterpret_cast<std::uintptr_t>(engineModule),sb=reinterpret_cast<std::uintptr_t>(studioModule);
    if(reinterpret_cast<std::uintptr_t>(e)!=eb+0x604248 || reinterpret_cast<std::uintptr_t>(s)!=sb+0x437018 ||
       !readable(e,4)||!readable(s,4)){status="Render interface object mismatch";return;}
    auto et=*reinterpret_cast<void***>(e),st=*reinterpret_cast<void***>(s);
    if(reinterpret_cast<std::uintptr_t>(et)!=eb+0x373864 || reinterpret_cast<std::uintptr_t>(st)!=sb+0x7f03c ||
       !readable(et,20*4)||!readable(st,26*4)){status="Render vtable mismatch";return;}
    // Unknown existing hooks are not bypassed or replaced.
    if(reinterpret_cast<std::uintptr_t>(et[19])!=eb+0xe0600 ||
       reinterpret_cast<std::uintptr_t>(st[25])!=sb+0x6a150){status="Render method changed / existing hook detected";return;}
    engineOriginal=reinterpret_cast<EngineDraw>(et[19]);studioOriginal=reinterpret_cast<StudioDraw>(st[25]);
    engineTable=et;studioTable=st;
    if(!patch(st,25,reinterpret_cast<void*>(studioOriginal),reinterpret_cast<void*>(&studioHook)))return;
    if(!patch(et,19,reinterpret_cast<void*>(engineOriginal),reinterpret_cast<void*>(&engineHook))) {
        patch(st,25,reinterpret_cast<void*>(&studioHook),reinterpret_cast<void*>(studioOriginal));return;
    }
    bound=true;status="Render hooks installed; awaiting enabled target draws";
    log("Visual DrawModelExecute[19] + Studio DrawModel[25] installed (offline-verified ABI; game test pending)");
}
inline void stop() {
    enabled=false;
    if(engineTable && source_camera::readable(engineTable,20*4))
        patch(engineTable,19,reinterpret_cast<void*>(&engineHook),reinterpret_cast<void*>(engineOriginal));
    if(studioTable && source_camera::readable(studioTable,26*4))
        patch(studioTable,25,reinterpret_cast<void*>(&studioHook),reinterpret_cast<void*>(studioOriginal));
    bound=false;
}
}
