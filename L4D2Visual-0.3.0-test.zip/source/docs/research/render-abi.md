# 上传构建的模型绘制证据

精确文件哈希和可重放指令样本见 render-profile.json。
公开 HL2SDK l4d2 声明仅辅助理解，槽位以实际二进制为准。

- engine VEngineModel016 工厂 d4660 返回对象 604248；构造器 dca2f 写入
  虚表 373864。槽 19 指向 e0600，三个栈参数，e0bfe 为 ret 0xc。
- DrawModelState header/hardware/renderable 位于 0/4/8；ModelRenderInfo 的
  renderable 位于 24、flags 位于 44。引擎 e0a88 将 state.renderable 写至
  Studio DrawModelInfo +24，e0b27 通过 Studio 虚表 +0x64（槽25）绘制。
- studiorender VStudioRender026 工厂 654c0 返回对象 437018；构造器6b4d1
  写入虚表7f03c。槽25为6a150，七个栈参数，6a3dc 为 ret 0x1c。
  第3个栈参数为骨骼指针；6a278 从 header+0x9c 取骨骼数量。
- 客户端21b3c与2abcb确认 studio 骨骼步长216、索引位于header+0xa0、
  名称通过骨骼首字段相对偏移读取，骨骼矩阵步长48。
- 队列分支6a278 → 67ed0 → 66e50：外部矩阵不在渲染内存池时，
  66e9d按 count*48 分配，66eb1复制到队列管理的存储。临时副本无需跨帧存活。
- 运行时对上述代码窗口、PE构建、对象、虚表和原函数RVA逐项检查。
  指令样本中的PE重定位字段使用mask处理ASLR，其余字节必须一致。

该证据不代表已在游戏运行验证。双脚来自当次模型元数据及渲染姿态；
不调用 SetupBones，不写回实体骨骼缓存，不改游戏碰撞数据。
